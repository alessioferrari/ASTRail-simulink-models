#ifndef __c3_ato_operating_modes_h__
#define __c3_ato_operating_modes_h__

/* Type Definitions */
#ifndef typedef_SFc3_ato_operating_modesInstanceStruct
#define typedef_SFc3_ato_operating_modesInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint32_T chartNumber;
  uint32_T instanceNumber;
  int32_T c3_sfEvent;
  uint8_T c3_tp_Power_ON;
  uint8_T c3_tp_ATO_Available_AV;
  uint8_T c3_tp_ATO_Config_CO;
  uint8_T c3_tp_ATO_Not_Available_NA;
  uint8_T c3_tp_ATO_Ready_RE;
  uint8_T c3_tp_ATO_Engaged_EG;
  uint8_T c3_tp_ATO_Disengaged_DE;
  uint8_T c3_tp_NO_Power_NP;
  uint8_T c3_tp_Fault_FA;
  uint8_T c3_is_active_c3_ato_operating_modes;
  uint8_T c3_is_c3_ato_operating_modes;
  uint8_T c3_is_Power_ON;
  boolean_T c3_l_op_conditions_OK;
  real_T c3_l_eng_conditions_OK;
  real_T c3_l_counter_expired;
  real_T c3_temporalCounter_i1;
  real_T c3_presentTime;
  real_T c3_elapsedTime;
  real_T c3_previousTime;
  boolean_T c3_in_msg_data_isPopped;
  boolean_T c3_in_msg_data_isForwarded;
  boolean_T c3_dataWrittenToVector[3];
  uint8_T c3_doSetSimStateSideEffects;
  const mxArray *c3_setSimStateSideEffectsInfo;
  void *c3_out_msg_data_request_msgInterface;
  real_T c3_out_msg_data_request_msgData;
  void *c3_in_msg_data_msgInterface;
  void *c3_in_msg_data_msgHandle;
  void *c3_in_msg_data_msgDataPtr;
  real_T c3_in_msg_data_msgData;
  void *c3_fEmlrtCtx;
  real_T *c3_in_fault;
  real_T *c3_in_power_on;
  real_T *c3_in_ATO_conditions_OK;
  real_T *c3_in_eng_conditions_OK;
  real_T *c3_in_TBL;
  real_T *c3_in_ETCS_conditions_OK;
  boolean_T *c3_in_train_moving;
  real_T *c3_out_full_serv_brake;
  real_T *c3_in_DRIVE;
  real_T *c3_out_msg_data_request;
} SFc3_ato_operating_modesInstanceStruct;

#endif                                 /*typedef_SFc3_ato_operating_modesInstanceStruct*/

/* Named Constants */

/* Variable Declarations */
extern struct SfDebugInstanceStruct *sfGlobalDebugInstanceStruct;

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c3_ato_operating_modes_get_eml_resolved_functions_info
  (void);

/* Function Definitions */
extern void sf_c3_ato_operating_modes_get_check_sum(mxArray *plhs[]);
extern void c3_ato_operating_modes_method_dispatcher(SimStruct *S, int_T method,
  void *data);

#endif
