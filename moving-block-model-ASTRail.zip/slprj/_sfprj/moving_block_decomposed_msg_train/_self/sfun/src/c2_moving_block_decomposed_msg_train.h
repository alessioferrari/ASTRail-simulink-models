#ifndef __c2_moving_block_decomposed_msg_train_h__
#define __c2_moving_block_decomposed_msg_train_h__

/* Type Definitions */
#ifndef struct_PR_msg_tag
#define struct_PR_msg_tag

struct PR_msg_tag
{
  real_T current_location;
  real_T current_timestamp;
};

#endif                                 /*struct_PR_msg_tag*/

#ifndef typedef_c2_PR_msg
#define typedef_c2_PR_msg

typedef struct PR_msg_tag c2_PR_msg;

#endif                                 /*typedef_c2_PR_msg*/

#ifndef struct_MA_msg_tag
#define struct_MA_msg_tag

struct MA_msg_tag
{
  real_T MA_timestamp;
  real_T flg_new_MA;
  real_T MA_value;
};

#endif                                 /*struct_MA_msg_tag*/

#ifndef typedef_c2_MA_msg
#define typedef_c2_MA_msg

typedef struct MA_msg_tag c2_MA_msg;

#endif                                 /*typedef_c2_MA_msg*/

#ifndef typedef_SFc2_moving_block_decomposed_msg_trainInstanceStruct
#define typedef_SFc2_moving_block_decomposed_msg_trainInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint32_T chartNumber;
  uint32_T instanceNumber;
  int32_T c2_sfEvent;
  uint8_T c2_tp_MESSAGE_QUEUE_MANAGER;
  uint8_T c2_tp_RBC_MAIN;
  uint8_T c2_tp_SEND_MA_TO_OBU;
  uint8_T c2_tp_WAIT_ACK;
  uint8_T c2_tp_FAIL;
  uint8_T c2_is_active_c2_moving_block_decomposed_msg_train;
  uint8_T c2_is_active_MESSAGE_QUEUE_MANAGER;
  uint8_T c2_is_RBC_MAIN;
  uint8_T c2_is_active_RBC_MAIN;
  real_T c2_l_timeref_last_MA_sent;
  real_T c2_l_count_MA_sent;
  real_T c2_RBC_REC_location_flg;
  real_T c2_MA_ACK_from_OBU_flg;
  real_T c2_INIT_TRAIN_POSITION_VALUE;
  real_T c2_previous_train_pos;
  real_T c2_previous_MA;
  real_T c2_OBU_current_timestamp;
  real_T c2_OBU_current_location;
  void *c2_RuntimeVar;
  int32_T c2_AreListenersActive;
  void **c2_fcnDataPtrs;
  char_T **c2_outMexFcnNames;
  char_T **c2_inMexFcnNames;
  char_T **c2_dataNames;
  int32_T c2_mlFcnLineNumber;
  int32_T c2_numFcnVars;
  int32_T *c2_statuses;
  boolean_T c2_RBC_REC_location_isPopped;
  boolean_T c2_RBC_REC_location_isForwarded;
  boolean_T c2_MA_ACK_from_OBU_isPopped;
  boolean_T c2_MA_ACK_from_OBU_isForwarded;
  boolean_T c2_dataWrittenToVector[9];
  uint8_T c2_doSetSimStateSideEffects;
  const mxArray *c2_setSimStateSideEffectsInfo;
  void *c2_RBC_REC_location_msgInterface;
  void *c2_RBC_REC_location_msgHandle;
  void *c2_RBC_REC_location_msgDataPtr;
  c2_PR_msg c2_RBC_REC_location_msgData;
  void *c2_RBC_SEND_MA_msgInterface;
  c2_MA_msg c2_RBC_SEND_MA_msgData;
  void *c2_MA_ACK_from_OBU_msgInterface;
  void *c2_MA_ACK_from_OBU_msgHandle;
  void *c2_MA_ACK_from_OBU_msgDataPtr;
  real_T c2_MA_ACK_from_OBU_msgData;
  void *c2_fEmlrtCtx;
  c2_MA_msg *c2_RBC_SEND_MA;
  uint8_T *c2_RBC_fail;
} SFc2_moving_block_decomposed_msg_trainInstanceStruct;

#endif                                 /*typedef_SFc2_moving_block_decomposed_msg_trainInstanceStruct*/

/* Named Constants */

/* Variable Declarations */
extern struct SfDebugInstanceStruct *sfGlobalDebugInstanceStruct;

/* Variable Definitions */

/* Function Declarations */
extern const mxArray
  *sf_c2_moving_block_decomposed_msg_train_get_eml_resolved_functions_info(void);

/* Function Definitions */
extern void sf_c2_moving_block_decomposed_msg_train_get_check_sum(mxArray *plhs[]);
extern void c2_moving_block_decomposed_msg_train_method_dispatcher(SimStruct *S,
  int_T method, void *data);

#endif
