/* Include files */

#include "moving_block_decomposed_msg_train_sfun.h"
#include "c2_moving_block_decomposed_msg_train.h"
#define CHARTINSTANCE_CHARTNUMBER      (chartInstance->chartNumber)
#define CHARTINSTANCE_INSTANCENUMBER   (chartInstance->instanceNumber)
#include "moving_block_decomposed_msg_train_sfun_debug_macros.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c_with_debugger(S, sfGlobalDebugInstanceStruct);

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization);
static void chart_debug_initialize_data_addresses(SimStruct *S);
static const mxArray* sf_opaque_get_hover_data_for_msg(void *chartInstance,
  int32_T msgSSID);

/* Type Definitions */

/* Named Constants */
#define CALL_EVENT                     (-1)
#define c2_IN_NO_ACTIVE_CHILD          ((uint8_T)0U)
#define c2_IN_FAIL                     ((uint8_T)1U)
#define c2_IN_SEND_MA_TO_OBU           ((uint8_T)2U)
#define c2_IN_WAIT_ACK                 ((uint8_T)3U)
#define c2_const_INIT_TRAIN_POSITION_VALUE (1.0E+6)

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;
static const char * c2_debug_family_names[2] = { "nargin", "nargout" };

static const char * c2_b_debug_family_names[2] = { "nargin", "nargout" };

static const char * c2_c_debug_family_names[5] = { "nargin", "nargout",
  "i_OBU_location", "i_previous_MA", "i_previous_train_pos" };

static const char * c2_d_debug_family_names[3] = { "nargin", "nargout",
  "o_timestamp" };

static const char * c2_e_debug_family_names[2] = { "nargin", "nargout" };

static const char * c2_f_debug_family_names[2] = { "nargin", "nargout" };

static const char * c2_g_debug_family_names[2] = { "nargin", "nargout" };

static const char * c2_h_debug_family_names[2] = { "nargin", "nargout" };

static const char * c2_i_debug_family_names[2] = { "nargin", "nargout" };

static const char * c2_j_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c2_k_debug_family_names[2] = { "nargin", "nargout" };

static const char * c2_l_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c2_m_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c2_n_debug_family_names[3] = { "nargin", "nargout",
  "sf_internal_predicateOutput" };

static const char * c2_sv0[5] = { "payload", "numPayloadsInQ", "payloadsInQ",
  "isPopped", "isForwarded" };

/* Function Declarations */
static void initialize_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void initialize_params_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void enable_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void disable_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void c2_update_debugger_state_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void set_sim_state_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_st);
static void c2_set_sim_state_side_effects_c2_moving_block_decomposed_msg_tra
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void finalize_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void sf_gateway_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void mdl_start_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void c2_enter_atomic_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void c2_enter_internal_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void c2_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void initSimStructsc2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void init_script_number_translation(uint32_T c2_machineNumber, uint32_T
  c2_chartNumber, uint32_T c2_instanceNumber);
static const mxArray *c2_sf_marshallOut(void *chartInstanceVoid, void *c2_inData);
static real_T c2_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_nargout, const char_T *c2_identifier);
static real_T c2_b_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static void c2_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData);
static const mxArray *c2_b_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData);
static boolean_T c2_c_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static void c2_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData);
static void c2_initialize_message_queues_for_chart
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void c2_sf_msg_discard_RBC_REC_location
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void c2_sf_msg_discard_MA_ACK_from_OBU
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void c2_sf_msg_reset_message_has_been_sent_RBC_SEND_MA
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void c2_read_msg_queue
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void c2_set_current_MA_value
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, real_T
   c2_i_OBU_location, real_T c2_i_previous_MA, real_T c2_i_previous_train_pos);
static const mxArray *c2_c_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData);
static int32_T c2_d_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static void c2_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData);
static const mxArray *c2_d_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData);
static uint8_T c2_e_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_b_tp_MESSAGE_QUEUE_MANAGER, const char_T *c2_identifier);
static uint8_T c2_f_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static void c2_d_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData);
static const mxArray *c2_RBC_SEND_MA_bus_io(void *chartInstanceVoid, void
  *c2_pData);
static const mxArray *c2_e_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData);
static c2_MA_msg c2_g_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static void c2_e_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData);
static void c2_h_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_b_dataWrittenToVector, const char_T *c2_identifier, boolean_T
   c2_y[9]);
static void c2_i_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId, boolean_T c2_y[9]);
static const mxArray *c2_j_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_b_setSimStateSideEffectsInfo, const char_T *c2_identifier);
static const mxArray *c2_k_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId);
static void c2_cleanup_message_queues_for_chart
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static const mxArray *c2_getMsgInfoFor_RBC_REC_location
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static const mxArray *c2_getMsgInfoFor_RBC_SEND_MA
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static const mxArray *c2_getMsgInfoFor_MA_ACK_from_OBU
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static const mxArray *sf_get_hover_data_for_msg
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, int32_T
   c2_ssid);
static void c2_sf_msg_send_RBC_SEND_MA
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static boolean_T c2_sf_msg_pop_RBC_REC_location
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static boolean_T c2_sf_msg_pop_MA_ACK_from_OBU
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void c2_init_sf_message_store_memory
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void init_dsm_address_info
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);
static void init_simulink_io_address
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance);

/* Function Definitions */
static void initialize_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  if (sf_is_first_init_cond(chartInstance->S)) {
    initSimStructsc2_moving_block_decomposed_msg_train(chartInstance);
    chart_debug_initialize_data_addresses(chartInstance->S);
  }

  chartInstance->c2_sfEvent = CALL_EVENT;
  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c2_doSetSimStateSideEffects = 0U;
  chartInstance->c2_setSimStateSideEffectsInfo = NULL;
  chartInstance->c2_is_active_MESSAGE_QUEUE_MANAGER = 0U;
  chartInstance->c2_tp_MESSAGE_QUEUE_MANAGER = 0U;
  chartInstance->c2_is_active_RBC_MAIN = 0U;
  chartInstance->c2_is_RBC_MAIN = c2_IN_NO_ACTIVE_CHILD;
  chartInstance->c2_tp_RBC_MAIN = 0U;
  chartInstance->c2_tp_FAIL = 0U;
  chartInstance->c2_tp_SEND_MA_TO_OBU = 0U;
  chartInstance->c2_tp_WAIT_ACK = 0U;
  chartInstance->c2_is_active_c2_moving_block_decomposed_msg_train = 0U;
  chartInstance->c2_INIT_TRAIN_POSITION_VALUE = 1.0E+6;
  _SFD_DATA_RANGE_CHECK(chartInstance->c2_INIT_TRAIN_POSITION_VALUE, 9U);
}

static void initialize_params_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void enable_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void disable_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void c2_update_debugger_state_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  uint32_T c2_prevAniVal;
  c2_prevAniVal = _SFD_GET_ANIMATION();
  _SFD_SET_ANIMATION(0U);
  _SFD_SET_HONOR_BREAKPOINTS(0U);
  if (chartInstance->c2_is_active_c2_moving_block_decomposed_msg_train == 1U) {
    _SFD_CC_CALL(CHART_ACTIVE_TAG, 1U, chartInstance->c2_sfEvent);
  }

  if (chartInstance->c2_is_active_MESSAGE_QUEUE_MANAGER == 1U) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 0U, chartInstance->c2_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 0U, chartInstance->c2_sfEvent);
  }

  if (chartInstance->c2_is_active_RBC_MAIN == 1U) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 2U, chartInstance->c2_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 2U, chartInstance->c2_sfEvent);
  }

  if (chartInstance->c2_is_RBC_MAIN == c2_IN_SEND_MA_TO_OBU) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 4U, chartInstance->c2_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 4U, chartInstance->c2_sfEvent);
  }

  if (chartInstance->c2_is_RBC_MAIN == c2_IN_WAIT_ACK) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 5U, chartInstance->c2_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 5U, chartInstance->c2_sfEvent);
  }

  if (chartInstance->c2_is_RBC_MAIN == c2_IN_FAIL) {
    _SFD_CS_CALL(STATE_ACTIVE_TAG, 3U, chartInstance->c2_sfEvent);
  } else {
    _SFD_CS_CALL(STATE_INACTIVE_TAG, 3U, chartInstance->c2_sfEvent);
  }

  _SFD_SET_ANIMATION(c2_prevAniVal);
  _SFD_SET_HONOR_BREAKPOINTS(1U);
  _SFD_ANIMATE();
}

static const mxArray *get_sim_state_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  const mxArray *c2_st;
  const mxArray *c2_y = NULL;
  real_T c2_hoistedGlobal;
  const mxArray *c2_b_y = NULL;
  real_T c2_b_hoistedGlobal;
  const mxArray *c2_c_y = NULL;
  real_T c2_c_hoistedGlobal;
  const mxArray *c2_d_y = NULL;
  real_T c2_d_hoistedGlobal;
  const mxArray *c2_e_y = NULL;
  real_T c2_e_hoistedGlobal;
  const mxArray *c2_f_y = NULL;
  real_T c2_f_hoistedGlobal;
  const mxArray *c2_g_y = NULL;
  real_T c2_g_hoistedGlobal;
  const mxArray *c2_h_y = NULL;
  real_T c2_h_hoistedGlobal;
  const mxArray *c2_i_y = NULL;
  uint8_T c2_i_hoistedGlobal;
  const mxArray *c2_j_y = NULL;
  uint8_T c2_j_hoistedGlobal;
  const mxArray *c2_k_y = NULL;
  uint8_T c2_k_hoistedGlobal;
  const mxArray *c2_l_y = NULL;
  uint8_T c2_l_hoistedGlobal;
  const mxArray *c2_m_y = NULL;
  const mxArray *c2_n_y = NULL;
  c2_st = NULL;
  c2_st = NULL;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_createcellmatrix(13, 1), false);
  c2_hoistedGlobal = chartInstance->c2_MA_ACK_from_OBU_flg;
  c2_b_y = NULL;
  sf_mex_assign(&c2_b_y, sf_mex_create("y", &c2_hoistedGlobal, 0, 0U, 0U, 0U, 0),
                false);
  sf_mex_setcell(c2_y, 0, c2_b_y);
  c2_b_hoistedGlobal = chartInstance->c2_OBU_current_location;
  c2_c_y = NULL;
  sf_mex_assign(&c2_c_y, sf_mex_create("y", &c2_b_hoistedGlobal, 0, 0U, 0U, 0U,
    0), false);
  sf_mex_setcell(c2_y, 1, c2_c_y);
  c2_c_hoistedGlobal = chartInstance->c2_OBU_current_timestamp;
  c2_d_y = NULL;
  sf_mex_assign(&c2_d_y, sf_mex_create("y", &c2_c_hoistedGlobal, 0, 0U, 0U, 0U,
    0), false);
  sf_mex_setcell(c2_y, 2, c2_d_y);
  c2_d_hoistedGlobal = chartInstance->c2_RBC_REC_location_flg;
  c2_e_y = NULL;
  sf_mex_assign(&c2_e_y, sf_mex_create("y", &c2_d_hoistedGlobal, 0, 0U, 0U, 0U,
    0), false);
  sf_mex_setcell(c2_y, 3, c2_e_y);
  c2_e_hoistedGlobal = chartInstance->c2_l_count_MA_sent;
  c2_f_y = NULL;
  sf_mex_assign(&c2_f_y, sf_mex_create("y", &c2_e_hoistedGlobal, 0, 0U, 0U, 0U,
    0), false);
  sf_mex_setcell(c2_y, 4, c2_f_y);
  c2_f_hoistedGlobal = chartInstance->c2_l_timeref_last_MA_sent;
  c2_g_y = NULL;
  sf_mex_assign(&c2_g_y, sf_mex_create("y", &c2_f_hoistedGlobal, 0, 0U, 0U, 0U,
    0), false);
  sf_mex_setcell(c2_y, 5, c2_g_y);
  c2_g_hoistedGlobal = chartInstance->c2_previous_MA;
  c2_h_y = NULL;
  sf_mex_assign(&c2_h_y, sf_mex_create("y", &c2_g_hoistedGlobal, 0, 0U, 0U, 0U,
    0), false);
  sf_mex_setcell(c2_y, 6, c2_h_y);
  c2_h_hoistedGlobal = chartInstance->c2_previous_train_pos;
  c2_i_y = NULL;
  sf_mex_assign(&c2_i_y, sf_mex_create("y", &c2_h_hoistedGlobal, 0, 0U, 0U, 0U,
    0), false);
  sf_mex_setcell(c2_y, 7, c2_i_y);
  c2_i_hoistedGlobal =
    chartInstance->c2_is_active_c2_moving_block_decomposed_msg_train;
  c2_j_y = NULL;
  sf_mex_assign(&c2_j_y, sf_mex_create("y", &c2_i_hoistedGlobal, 3, 0U, 0U, 0U,
    0), false);
  sf_mex_setcell(c2_y, 8, c2_j_y);
  c2_j_hoistedGlobal = chartInstance->c2_is_active_RBC_MAIN;
  c2_k_y = NULL;
  sf_mex_assign(&c2_k_y, sf_mex_create("y", &c2_j_hoistedGlobal, 3, 0U, 0U, 0U,
    0), false);
  sf_mex_setcell(c2_y, 9, c2_k_y);
  c2_k_hoistedGlobal = chartInstance->c2_is_active_MESSAGE_QUEUE_MANAGER;
  c2_l_y = NULL;
  sf_mex_assign(&c2_l_y, sf_mex_create("y", &c2_k_hoistedGlobal, 3, 0U, 0U, 0U,
    0), false);
  sf_mex_setcell(c2_y, 10, c2_l_y);
  c2_l_hoistedGlobal = chartInstance->c2_is_RBC_MAIN;
  c2_m_y = NULL;
  sf_mex_assign(&c2_m_y, sf_mex_create("y", &c2_l_hoistedGlobal, 3, 0U, 0U, 0U,
    0), false);
  sf_mex_setcell(c2_y, 11, c2_m_y);
  c2_n_y = NULL;
  sf_mex_assign(&c2_n_y, sf_mex_create("y",
    chartInstance->c2_dataWrittenToVector, 11, 0U, 1U, 0U, 1, 9), false);
  sf_mex_setcell(c2_y, 12, c2_n_y);
  sf_mex_assign(&c2_st, c2_y, false);
  return c2_st;
}

static void set_sim_state_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_st)
{
  const mxArray *c2_u;
  boolean_T c2_bv0[9];
  int32_T c2_i0;
  c2_u = sf_mex_dup(c2_st);
  chartInstance->c2_MA_ACK_from_OBU_flg = c2_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c2_u, 0)), "MA_ACK_from_OBU_flg");
  chartInstance->c2_OBU_current_location = c2_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c2_u, 1)), "OBU_current_location");
  chartInstance->c2_OBU_current_timestamp = c2_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c2_u, 2)), "OBU_current_timestamp");
  chartInstance->c2_RBC_REC_location_flg = c2_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c2_u, 3)), "RBC_REC_location_flg");
  chartInstance->c2_l_count_MA_sent = c2_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c2_u, 4)), "l_count_MA_sent");
  chartInstance->c2_l_timeref_last_MA_sent = c2_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c2_u, 5)), "l_timeref_last_MA_sent");
  chartInstance->c2_previous_MA = c2_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c2_u, 6)), "previous_MA");
  chartInstance->c2_previous_train_pos = c2_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c2_u, 7)), "previous_train_pos");
  chartInstance->c2_is_active_c2_moving_block_decomposed_msg_train =
    c2_e_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c2_u, 8)),
    "is_active_c2_moving_block_decomposed_msg_train");
  chartInstance->c2_is_active_RBC_MAIN = c2_e_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c2_u, 9)), "is_active_RBC_MAIN");
  chartInstance->c2_is_active_MESSAGE_QUEUE_MANAGER = c2_e_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c2_u, 10)),
     "is_active_MESSAGE_QUEUE_MANAGER");
  chartInstance->c2_is_RBC_MAIN = c2_e_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c2_u, 11)), "is_RBC_MAIN");
  c2_h_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c2_u, 12)),
                        "dataWrittenToVector", c2_bv0);
  for (c2_i0 = 0; c2_i0 < 9; c2_i0++) {
    chartInstance->c2_dataWrittenToVector[c2_i0] = c2_bv0[c2_i0];
  }

  sf_mex_assign(&chartInstance->c2_setSimStateSideEffectsInfo,
                c2_j_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c2_u, 13)), "setSimStateSideEffectsInfo"), true);
  sf_mex_destroy(&c2_u);
  chartInstance->c2_doSetSimStateSideEffects = 1U;
  c2_update_debugger_state_c2_moving_block_decomposed_msg_train(chartInstance);
  sf_mex_destroy(&c2_st);
}

static void c2_set_sim_state_side_effects_c2_moving_block_decomposed_msg_tra
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  if (chartInstance->c2_doSetSimStateSideEffects != 0) {
    chartInstance->c2_tp_MESSAGE_QUEUE_MANAGER = (uint8_T)
      (chartInstance->c2_is_active_MESSAGE_QUEUE_MANAGER == 1U);
    chartInstance->c2_tp_RBC_MAIN = (uint8_T)
      (chartInstance->c2_is_active_RBC_MAIN == 1U);
    chartInstance->c2_tp_FAIL = (uint8_T)(chartInstance->c2_is_RBC_MAIN ==
      c2_IN_FAIL);
    chartInstance->c2_tp_SEND_MA_TO_OBU = (uint8_T)
      (chartInstance->c2_is_RBC_MAIN == c2_IN_SEND_MA_TO_OBU);
    chartInstance->c2_tp_WAIT_ACK = (uint8_T)(chartInstance->c2_is_RBC_MAIN ==
      c2_IN_WAIT_ACK);
    chartInstance->c2_doSetSimStateSideEffects = 0U;
  }
}

static void finalize_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  sfListenerTerminate(chartInstance->c2_RuntimeVar);
  c2_cleanup_message_queues_for_chart(chartInstance);
  sf_mex_destroy(&chartInstance->c2_setSimStateSideEffectsInfo);
}

static void sf_gateway_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  c2_set_sim_state_side_effects_c2_moving_block_decomposed_msg_tra(chartInstance);
  _SFD_SYMBOL_SCOPE_PUSH(0U, 0U);
  _sfTime_ = sf_get_time(chartInstance->S);
  _SFD_CC_CALL(CHART_ENTER_SFUNCTION_TAG, 1U, chartInstance->c2_sfEvent);
  _SFD_DATA_RANGE_CHECK((real_T)*chartInstance->c2_RBC_fail, 8U);
  chartInstance->c2_sfEvent = CALL_EVENT;
  chartInstance->c2_RBC_REC_location_isPopped = false;
  chartInstance->c2_RBC_REC_location_isForwarded = false;
  chartInstance->c2_MA_ACK_from_OBU_isPopped = false;
  chartInstance->c2_MA_ACK_from_OBU_isForwarded = false;
  c2_c2_moving_block_decomposed_msg_train(chartInstance);
  c2_sf_msg_discard_RBC_REC_location(chartInstance);
  c2_sf_msg_discard_MA_ACK_from_OBU(chartInstance);
  c2_sf_msg_reset_message_has_been_sent_RBC_SEND_MA(chartInstance);
  _SFD_SYMBOL_SCOPE_POP();
  _SFD_CHECK_FOR_STATE_INCONSISTENCY
    (_moving_block_decomposed_msg_trainMachineNumber_,
     chartInstance->chartNumber, chartInstance->instanceNumber);
}

static void mdl_start_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  chartInstance->c2_RuntimeVar = sfListenerInitializeUsingSimStruct
    (chartInstance->S);
  sfListenerInitializeRuntimeVars(chartInstance->c2_RuntimeVar,
    &chartInstance->c2_AreListenersActive, 0, 1, &chartInstance->c2_numFcnVars,
    &chartInstance->c2_dataNames, &chartInstance->c2_fcnDataPtrs,
    &chartInstance->c2_outMexFcnNames, &chartInstance->c2_inMexFcnNames,
    &chartInstance->c2_statuses, &chartInstance->c2_mlFcnLineNumber);
  c2_init_sf_message_store_memory(chartInstance);
  c2_initialize_message_queues_for_chart(chartInstance);
  sim_mode_is_external(chartInstance->S);
}

static void c2_enter_atomic_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  _SFD_CC_CALL(CHART_ENTER_ENTRY_FUNCTION_TAG, 1U, chartInstance->c2_sfEvent);
  chartInstance->c2_is_active_c2_moving_block_decomposed_msg_train = 1U;
  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 1U, chartInstance->c2_sfEvent);
}

static void c2_enter_internal_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  uint32_T c2_debug_family_var_map[2];
  real_T c2_nargin = 0.0;
  real_T c2_nargout = 0.0;
  real_T c2_b_nargin = 0.0;
  real_T c2_b_nargout = 0.0;
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 76, 1);
  }

  chartInstance->c2_is_active_MESSAGE_QUEUE_MANAGER = 1U;
  _SFD_CS_CALL(STATE_ACTIVE_TAG, 0U, chartInstance->c2_sfEvent);
  chartInstance->c2_tp_MESSAGE_QUEUE_MANAGER = 1U;
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c2_e_debug_family_names,
    c2_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_nargin, 0U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_nargout, 1U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  chartInstance->c2_RBC_REC_location_flg = 0.0;
  chartInstance->c2_dataWrittenToVector[2U] = true;
  chartInstance->c2_dataWrittenToVector[2U] = true;
  _SFD_DATA_RANGE_CHECK(chartInstance->c2_RBC_REC_location_flg, 3U);
  chartInstance->c2_MA_ACK_from_OBU_flg = 0.0;
  chartInstance->c2_dataWrittenToVector[3U] = true;
  chartInstance->c2_dataWrittenToVector[3U] = true;
  _SFD_DATA_RANGE_CHECK(chartInstance->c2_MA_ACK_from_OBU_flg, 0U);
  c2_read_msg_queue(chartInstance);
  _SFD_SYMBOL_SCOPE_POP();
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 76, 1);
  }

  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 22, 1);
  }

  chartInstance->c2_is_active_RBC_MAIN = 1U;
  _SFD_CS_CALL(STATE_ACTIVE_TAG, 2U, chartInstance->c2_sfEvent);
  chartInstance->c2_tp_RBC_MAIN = 1U;
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c2_g_debug_family_names,
    c2_debug_family_var_map);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_b_nargin, 0U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_b_nargout, 1U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  chartInstance->c2_previous_train_pos = c2_const_INIT_TRAIN_POSITION_VALUE;
  chartInstance->c2_dataWrittenToVector[4U] = true;
  chartInstance->c2_dataWrittenToVector[4U] = true;
  _SFD_DATA_RANGE_CHECK(chartInstance->c2_previous_train_pos, 7U);
  chartInstance->c2_previous_MA = 0.0;
  chartInstance->c2_dataWrittenToVector[5U] = true;
  chartInstance->c2_dataWrittenToVector[5U] = true;
  _SFD_DATA_RANGE_CHECK(chartInstance->c2_previous_MA, 6U);
  _SFD_SYMBOL_SCOPE_POP();
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 22, 1);
  }

  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 24, 7);
  }

  _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 0U, chartInstance->c2_sfEvent);
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 24, 7);
  }

  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 24, 8);
  }

  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 24, 8);
  }

  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 23, 1);
  }

  chartInstance->c2_is_RBC_MAIN = c2_IN_SEND_MA_TO_OBU;
  _SFD_CS_CALL(STATE_ACTIVE_TAG, 4U, chartInstance->c2_sfEvent);
  chartInstance->c2_tp_SEND_MA_TO_OBU = 1U;
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 23, 1);
  }
}

static void c2_c2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  uint32_T c2_debug_family_var_map[2];
  real_T c2_nargin = 0.0;
  real_T c2_nargout = 0.0;
  uint32_T c2_b_debug_family_var_map[3];
  real_T c2_b_nargin = 0.0;
  real_T c2_c_nargin = 0.0;
  real_T c2_b_nargout = 1.0;
  real_T c2_c_nargout = 1.0;
  boolean_T c2_out;
  boolean_T c2_b_out;
  real_T c2_d_nargin = 0.0;
  real_T c2_e_nargin = 0.0;
  real_T c2_f_nargin = 0.0;
  real_T c2_d_nargout = 1.0;
  real_T c2_e_nargout = 0.0;
  real_T c2_f_nargout = 1.0;
  boolean_T c2_c_out;
  boolean_T c2_d_out;
  real_T c2_g_nargin = 0.0;
  real_T c2_g_nargout = 0.0;
  real_T c2_h_nargin = 0.0;
  real_T c2_h_nargout = 0.0;
  boolean_T c2_sf_internal_predicateOutput;
  real_T c2_i_nargin = 1.0;
  real_T c2_i_nargout = 1.0;
  real_T c2_o_timestamp;
  real_T c2_j_nargin = 0.0;
  real_T c2_j_nargout = 0.0;
  real_T c2_k_nargin = 1.0;
  real_T c2_k_nargout = 1.0;
  real_T c2_b_o_timestamp;
  boolean_T guard1 = false;
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 0, 0);
  }

  _SFD_CC_CALL(CHART_ENTER_DURING_FUNCTION_TAG, 1U, chartInstance->c2_sfEvent);
  if (chartInstance->c2_is_active_c2_moving_block_decomposed_msg_train == 0U) {
    c2_enter_atomic_c2_moving_block_decomposed_msg_train(chartInstance);
    c2_enter_internal_c2_moving_block_decomposed_msg_train(chartInstance);
  } else {
    _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 0U, chartInstance->c2_sfEvent);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 76, 2);
    }

    _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c2_f_debug_family_names,
      c2_debug_family_var_map);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_nargin, 0U, c2_sf_marshallOut,
      c2_sf_marshallIn);
    _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_nargout, 1U, c2_sf_marshallOut,
      c2_sf_marshallIn);
    c2_read_msg_queue(chartInstance);
    _SFD_SYMBOL_SCOPE_POP();
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 76, 2);
    }

    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 0U, chartInstance->c2_sfEvent);
    _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 2U, chartInstance->c2_sfEvent);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 22, 2);
    }

    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 22, 2);
    }

    switch (chartInstance->c2_is_RBC_MAIN) {
     case c2_IN_FAIL:
      CV_STATE_EVAL(2, 0, c2_IN_FAIL);
      _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 3U,
                   chartInstance->c2_sfEvent);
      if (chartInstance->c2_AreListenersActive == 1) {
        sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 41, 2);
      }

      if (chartInstance->c2_AreListenersActive == 1) {
        sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 41, 2);
      }

      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 3U, chartInstance->c2_sfEvent);
      break;

     case c2_IN_SEND_MA_TO_OBU:
      CV_STATE_EVAL(2, 0, c2_IN_SEND_MA_TO_OBU);
      _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 1U,
                   chartInstance->c2_sfEvent);
      if (chartInstance->c2_AreListenersActive == 1) {
        sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 29, 6);
      }

      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c2_j_debug_family_names,
        c2_b_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_b_nargin, 0U, c2_sf_marshallOut,
        c2_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_b_nargout, 1U, c2_sf_marshallOut,
        c2_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_out, 2U, c2_b_sf_marshallOut,
        c2_b_sf_marshallIn);
      if (!chartInstance->c2_dataWrittenToVector[2U]) {
        _SFD_DATA_READ_BEFORE_WRITE_ERROR(3U);
      }

      if (!chartInstance->c2_dataWrittenToVector[2U]) {
        _SFD_DATA_READ_BEFORE_WRITE_ERROR(3U);
      }

      if (CV_EML_COND(1, 0, 0, CV_RELATIONAL_EVAL(5U, 1U, 0,
            chartInstance->c2_RBC_REC_location_flg, 1.0, -1, 0U,
            chartInstance->c2_RBC_REC_location_flg == 1.0)) && CV_EML_COND(1, 0,
           1, CV_RELATIONAL_EVAL(5U, 1U, 1, (real_T)*chartInstance->c2_RBC_fail,
            0.0, -1, 0U, (real_T)*chartInstance->c2_RBC_fail == 0.0))) {
        CV_EML_MCDC(1, 0, 0, true);
        CV_EML_IF(1, 0, 0, true);
        c2_out = true;
      } else {
        CV_EML_MCDC(1, 0, 0, false);
        CV_EML_IF(1, 0, 0, false);
        c2_out = false;
      }

      _SFD_SYMBOL_SCOPE_POP();
      if (chartInstance->c2_AreListenersActive == 1) {
        sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 29, 6);
      }

      if (c2_out) {
        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 29, 7);
        }

        _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 1U, chartInstance->c2_sfEvent);
        _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c2_k_debug_family_names,
          c2_debug_family_var_map);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_e_nargin, 0U, c2_sf_marshallOut,
          c2_sf_marshallIn);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_e_nargout, 1U,
          c2_sf_marshallOut, c2_sf_marshallIn);
        slMessageRtDiagnosticCheck
          (chartInstance->c2_RBC_REC_location_msgInterface, NULL,
           "OnPayloadRead", 29U, 72, 38);
        chartInstance->c2_OBU_current_location = *(real_T *)&((char_T *)
          (c2_PR_msg *)chartInstance->c2_RBC_REC_location_msgDataPtr)[0];
        chartInstance->c2_dataWrittenToVector[7U] = true;
        chartInstance->c2_dataWrittenToVector[7U] = true;
        _SFD_DATA_RANGE_CHECK(chartInstance->c2_OBU_current_location, 1U);
        slMessageRtDiagnosticCheck
          (chartInstance->c2_RBC_REC_location_msgInterface, NULL,
           "OnPayloadRead", 29U, 136, 39);
        chartInstance->c2_OBU_current_timestamp = *(real_T *)&((char_T *)
          (c2_PR_msg *)chartInstance->c2_RBC_REC_location_msgDataPtr)[8];
        chartInstance->c2_dataWrittenToVector[6U] = true;
        chartInstance->c2_dataWrittenToVector[6U] = true;
        _SFD_DATA_RANGE_CHECK(chartInstance->c2_OBU_current_timestamp, 2U);
        *(real_T *)&((char_T *)chartInstance->c2_RBC_SEND_MA)[8] = 1.0;
        if (!chartInstance->c2_dataWrittenToVector[7U]) {
          _SFD_DATA_READ_BEFORE_WRITE_ERROR(1U);
        }

        if (!chartInstance->c2_dataWrittenToVector[5U]) {
          _SFD_DATA_READ_BEFORE_WRITE_ERROR(6U);
        }

        if (!chartInstance->c2_dataWrittenToVector[4U]) {
          _SFD_DATA_READ_BEFORE_WRITE_ERROR(7U);
        }

        if (!chartInstance->c2_dataWrittenToVector[7U]) {
          _SFD_DATA_READ_BEFORE_WRITE_ERROR(1U);
        }

        if (!chartInstance->c2_dataWrittenToVector[5U]) {
          _SFD_DATA_READ_BEFORE_WRITE_ERROR(6U);
        }

        if (!chartInstance->c2_dataWrittenToVector[4U]) {
          _SFD_DATA_READ_BEFORE_WRITE_ERROR(7U);
        }

        c2_set_current_MA_value(chartInstance,
          chartInstance->c2_OBU_current_location, chartInstance->c2_previous_MA,
          chartInstance->c2_previous_train_pos);
        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 43, 3);
        }

        _SFD_CS_CALL(FUNCTION_ACTIVE_TAG, 7U, chartInstance->c2_sfEvent);
        _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c2_d_debug_family_names,
          c2_b_debug_family_var_map);
        _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 7U,
                     chartInstance->c2_sfEvent);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_i_nargin, 0U, c2_sf_marshallOut,
          c2_sf_marshallIn);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_i_nargout, 1U,
          c2_sf_marshallOut, c2_sf_marshallIn);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_o_timestamp, 2U,
          c2_sf_marshallOut, c2_sf_marshallIn);
        _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 3U, chartInstance->c2_sfEvent);
        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 45, 7);
        }

        c2_o_timestamp = _sfTime_;
        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 45, 7);
        }

        _SFD_SYMBOL_SCOPE_POP();
        _SFD_CS_CALL(FUNCTION_INACTIVE_TAG, 7U, chartInstance->c2_sfEvent);
        _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 7U, chartInstance->c2_sfEvent);
        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 43, 3);
        }

        *(real_T *)&((char_T *)chartInstance->c2_RBC_SEND_MA)[0] =
          c2_o_timestamp;
        _SFD_CM_CALL(MESSAGE_SEND_BREAKPOINT_TAG, 17U, (uint32_T)
                     chartInstance->c2_sfEvent);
        slMessageRtDiagnosticCheck(chartInstance->c2_RBC_SEND_MA_msgInterface,
          NULL, "OnSend", 29U, 357, 17);
        c2_sf_msg_send_RBC_SEND_MA(chartInstance);
        _SFD_SYMBOL_SCOPE_POP();
        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 29, 7);
        }

        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 23, 4);
        }

        chartInstance->c2_tp_SEND_MA_TO_OBU = 0U;
        chartInstance->c2_is_RBC_MAIN = c2_IN_NO_ACTIVE_CHILD;
        _SFD_CS_CALL(STATE_INACTIVE_TAG, 4U, chartInstance->c2_sfEvent);
        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 23, 4);
        }

        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 29, 8);
        }

        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 29, 8);
        }

        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 58, 1);
        }

        chartInstance->c2_is_RBC_MAIN = c2_IN_WAIT_ACK;
        _SFD_CS_CALL(STATE_ACTIVE_TAG, 5U, chartInstance->c2_sfEvent);
        chartInstance->c2_tp_WAIT_ACK = 1U;
        _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c2_h_debug_family_names,
          c2_debug_family_var_map);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_j_nargin, 0U, c2_sf_marshallOut,
          c2_sf_marshallIn);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_j_nargout, 1U,
          c2_sf_marshallOut, c2_sf_marshallIn);
        chartInstance->c2_l_count_MA_sent = 1.0;
        chartInstance->c2_dataWrittenToVector[1U] = true;
        chartInstance->c2_dataWrittenToVector[1U] = true;
        _SFD_DATA_RANGE_CHECK(chartInstance->c2_l_count_MA_sent, 4U);
        chartInstance->c2_l_timeref_last_MA_sent = _sfTime_;
        chartInstance->c2_dataWrittenToVector[0U] = true;
        chartInstance->c2_dataWrittenToVector[0U] = true;
        _SFD_DATA_RANGE_CHECK(chartInstance->c2_l_timeref_last_MA_sent, 5U);
        _SFD_SYMBOL_SCOPE_POP();
        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 58, 1);
        }
      } else {
        _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 2U,
                     chartInstance->c2_sfEvent);
        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 42, 6);
        }

        _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c2_n_debug_family_names,
          c2_b_debug_family_var_map);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_d_nargin, 0U, c2_sf_marshallOut,
          c2_sf_marshallIn);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_d_nargout, 1U,
          c2_sf_marshallOut, c2_sf_marshallIn);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_c_out, 2U, c2_b_sf_marshallOut,
          c2_b_sf_marshallIn);
        c2_c_out = CV_EML_IF(2, 0, 0, CV_RELATIONAL_EVAL(5U, 2U, 0, (real_T)
          *chartInstance->c2_RBC_fail, 1.0, -1, 0U, (real_T)
          *chartInstance->c2_RBC_fail == 1.0));
        _SFD_SYMBOL_SCOPE_POP();
        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 42, 6);
        }

        if (c2_c_out) {
          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 42, 7);
          }

          _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 2U, chartInstance->c2_sfEvent);
          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 42, 7);
          }

          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 23, 4);
          }

          chartInstance->c2_tp_SEND_MA_TO_OBU = 0U;
          chartInstance->c2_is_RBC_MAIN = c2_IN_NO_ACTIVE_CHILD;
          _SFD_CS_CALL(STATE_INACTIVE_TAG, 4U, chartInstance->c2_sfEvent);
          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 23, 4);
          }

          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 42, 8);
          }

          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 42, 8);
          }

          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 41, 1);
          }

          chartInstance->c2_is_RBC_MAIN = c2_IN_FAIL;
          _SFD_CS_CALL(STATE_ACTIVE_TAG, 3U, chartInstance->c2_sfEvent);
          chartInstance->c2_tp_FAIL = 1U;
          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 41, 1);
          }
        } else {
          _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 4U,
                       chartInstance->c2_sfEvent);
          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 23, 2);
          }

          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 23, 2);
          }
        }
      }

      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 4U, chartInstance->c2_sfEvent);
      break;

     case c2_IN_WAIT_ACK:
      CV_STATE_EVAL(2, 0, c2_IN_WAIT_ACK);
      _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 12U,
                   chartInstance->c2_sfEvent);
      if (chartInstance->c2_AreListenersActive == 1) {
        sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 73, 6);
      }

      _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c2_m_debug_family_names,
        c2_b_debug_family_var_map);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_c_nargin, 0U, c2_sf_marshallOut,
        c2_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_c_nargout, 1U, c2_sf_marshallOut,
        c2_sf_marshallIn);
      _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_b_out, 2U, c2_b_sf_marshallOut,
        c2_b_sf_marshallIn);
      if (!chartInstance->c2_dataWrittenToVector[1U]) {
        _SFD_DATA_READ_BEFORE_WRITE_ERROR(4U);
      }

      if (!chartInstance->c2_dataWrittenToVector[1U]) {
        _SFD_DATA_READ_BEFORE_WRITE_ERROR(4U);
      }

      guard1 = false;
      if (CV_EML_COND(12, 0, 0, CV_RELATIONAL_EVAL(5U, 12U, 0,
            chartInstance->c2_l_count_MA_sent, 3.0, -1, 5U,
            chartInstance->c2_l_count_MA_sent >= 3.0))) {
        if (CV_EML_COND(12, 0, 1, CV_RELATIONAL_EVAL(5U, 12U, 1, _sfTime_ -
              chartInstance->c2_l_timeref_last_MA_sent, 1000.0, -1, 4U, _sfTime_
              - chartInstance->c2_l_timeref_last_MA_sent > 1000.0))) {
          CV_EML_MCDC(12, 0, 0, true);
          CV_EML_IF(12, 0, 0, true);
          c2_b_out = true;
        } else {
          guard1 = true;
        }
      } else {
        if (!chartInstance->c2_dataWrittenToVector[0U]) {
          _SFD_DATA_READ_BEFORE_WRITE_ERROR(5U);
        }

        if (!chartInstance->c2_dataWrittenToVector[0U]) {
          _SFD_DATA_READ_BEFORE_WRITE_ERROR(5U);
        }

        guard1 = true;
      }

      if (guard1) {
        CV_EML_MCDC(12, 0, 0, false);
        CV_EML_IF(12, 0, 0, false);
        c2_b_out = false;
      }

      _SFD_SYMBOL_SCOPE_POP();
      if (chartInstance->c2_AreListenersActive == 1) {
        sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 73, 6);
      }

      if (c2_b_out) {
        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 73, 7);
        }

        _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 12U, chartInstance->c2_sfEvent);
        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 73, 7);
        }

        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 58, 4);
        }

        chartInstance->c2_tp_WAIT_ACK = 0U;
        chartInstance->c2_is_RBC_MAIN = c2_IN_NO_ACTIVE_CHILD;
        _SFD_CS_CALL(STATE_INACTIVE_TAG, 5U, chartInstance->c2_sfEvent);
        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 58, 4);
        }

        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 73, 8);
        }

        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 73, 8);
        }

        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 23, 1);
        }

        chartInstance->c2_is_RBC_MAIN = c2_IN_SEND_MA_TO_OBU;
        _SFD_CS_CALL(STATE_ACTIVE_TAG, 4U, chartInstance->c2_sfEvent);
        chartInstance->c2_tp_SEND_MA_TO_OBU = 1U;
        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 23, 1);
        }
      } else {
        _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 5U,
                     chartInstance->c2_sfEvent);
        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 60, 6);
        }

        _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c2_l_debug_family_names,
          c2_b_debug_family_var_map);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_f_nargin, 0U, c2_sf_marshallOut,
          c2_sf_marshallIn);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_f_nargout, 1U,
          c2_sf_marshallOut, c2_sf_marshallIn);
        _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_d_out, 2U, c2_b_sf_marshallOut,
          c2_b_sf_marshallIn);
        c2_d_out = CV_EML_IF(5, 0, 0, CV_RELATIONAL_EVAL(5U, 5U, 0, (real_T)
          *chartInstance->c2_RBC_fail, 1.0, -1, 0U, (real_T)
          *chartInstance->c2_RBC_fail == 1.0));
        _SFD_SYMBOL_SCOPE_POP();
        if (chartInstance->c2_AreListenersActive == 1) {
          sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 60, 6);
        }

        if (c2_d_out) {
          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 60, 7);
          }

          _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 5U, chartInstance->c2_sfEvent);
          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 60, 7);
          }

          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 58, 4);
          }

          chartInstance->c2_tp_WAIT_ACK = 0U;
          chartInstance->c2_is_RBC_MAIN = c2_IN_NO_ACTIVE_CHILD;
          _SFD_CS_CALL(STATE_INACTIVE_TAG, 5U, chartInstance->c2_sfEvent);
          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 58, 4);
          }

          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 60, 8);
          }

          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 60, 8);
          }

          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 41, 1);
          }

          chartInstance->c2_is_RBC_MAIN = c2_IN_FAIL;
          _SFD_CS_CALL(STATE_ACTIVE_TAG, 3U, chartInstance->c2_sfEvent);
          chartInstance->c2_tp_FAIL = 1U;
          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 41, 1);
          }
        } else {
          _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 5U,
                       chartInstance->c2_sfEvent);
          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 58, 2);
          }

          _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c2_i_debug_family_names,
            c2_debug_family_var_map);
          _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_g_nargin, 0U,
            c2_sf_marshallOut, c2_sf_marshallIn);
          _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_g_nargout, 1U,
            c2_sf_marshallOut, c2_sf_marshallIn);
          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 61, 3);
          }

          _SFD_CS_CALL(FUNCTION_ACTIVE_TAG, 6U, chartInstance->c2_sfEvent);
          _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c2_b_debug_family_names,
            c2_debug_family_var_map);
          _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 6U,
                       chartInstance->c2_sfEvent);
          _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_h_nargin, 0U,
            c2_sf_marshallOut, c2_sf_marshallIn);
          _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_h_nargout, 1U,
            c2_sf_marshallOut, c2_sf_marshallIn);
          _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 6U, chartInstance->c2_sfEvent);
          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 63, 7);
          }

          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 63, 7);
          }

          _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 7U,
                       chartInstance->c2_sfEvent);
          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 65, 6);
          }

          if (!chartInstance->c2_dataWrittenToVector[0U]) {
            _SFD_DATA_READ_BEFORE_WRITE_ERROR(5U);
          }

          if (!chartInstance->c2_dataWrittenToVector[0U]) {
            _SFD_DATA_READ_BEFORE_WRITE_ERROR(5U);
          }

          c2_sf_internal_predicateOutput = CV_EML_IF(7, 0, 0, CV_RELATIONAL_EVAL
            (5U, 7U, 0, _sfTime_ - chartInstance->c2_l_timeref_last_MA_sent, 1.0,
             -1, 4U, _sfTime_ - chartInstance->c2_l_timeref_last_MA_sent > 1.0));
          if (c2_sf_internal_predicateOutput) {
            _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 7U, chartInstance->c2_sfEvent);
            if (chartInstance->c2_AreListenersActive == 1) {
              sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 65,
                7);
            }

            if (chartInstance->c2_AreListenersActive == 1) {
              sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 65, 6);
            }

            if (chartInstance->c2_AreListenersActive == 1) {
              sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 65, 7);
            }

            _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 8U, chartInstance->c2_sfEvent);
            if (chartInstance->c2_AreListenersActive == 1) {
              sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 67,
                7);
            }

            chartInstance->c2_l_timeref_last_MA_sent = _sfTime_;
            chartInstance->c2_dataWrittenToVector[0U] = true;
            chartInstance->c2_dataWrittenToVector[0U] = true;
            _SFD_DATA_RANGE_CHECK(chartInstance->c2_l_timeref_last_MA_sent, 5U);
            if (!chartInstance->c2_dataWrittenToVector[1U]) {
              _SFD_DATA_READ_BEFORE_WRITE_ERROR(4U);
            }

            if (!chartInstance->c2_dataWrittenToVector[1U]) {
              _SFD_DATA_READ_BEFORE_WRITE_ERROR(4U);
            }

            chartInstance->c2_l_count_MA_sent++;
            chartInstance->c2_dataWrittenToVector[1U] = true;
            chartInstance->c2_dataWrittenToVector[1U] = true;
            _SFD_DATA_RANGE_CHECK(chartInstance->c2_l_count_MA_sent, 4U);
            *(real_T *)&((char_T *)chartInstance->c2_RBC_SEND_MA)[8] = 1.0;
            if (!chartInstance->c2_dataWrittenToVector[7U]) {
              _SFD_DATA_READ_BEFORE_WRITE_ERROR(1U);
            }

            if (!chartInstance->c2_dataWrittenToVector[5U]) {
              _SFD_DATA_READ_BEFORE_WRITE_ERROR(6U);
            }

            if (!chartInstance->c2_dataWrittenToVector[4U]) {
              _SFD_DATA_READ_BEFORE_WRITE_ERROR(7U);
            }

            if (!chartInstance->c2_dataWrittenToVector[7U]) {
              _SFD_DATA_READ_BEFORE_WRITE_ERROR(1U);
            }

            if (!chartInstance->c2_dataWrittenToVector[5U]) {
              _SFD_DATA_READ_BEFORE_WRITE_ERROR(6U);
            }

            if (!chartInstance->c2_dataWrittenToVector[4U]) {
              _SFD_DATA_READ_BEFORE_WRITE_ERROR(7U);
            }

            c2_set_current_MA_value(chartInstance,
              chartInstance->c2_OBU_current_location,
              chartInstance->c2_previous_MA,
              chartInstance->c2_previous_train_pos);
            if (chartInstance->c2_AreListenersActive == 1) {
              sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 43,
                3);
            }

            _SFD_CS_CALL(FUNCTION_ACTIVE_TAG, 7U, chartInstance->c2_sfEvent);
            _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 3U, 3U, c2_d_debug_family_names,
              c2_b_debug_family_var_map);
            _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 7U,
                         chartInstance->c2_sfEvent);
            _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_k_nargin, 0U,
              c2_sf_marshallOut, c2_sf_marshallIn);
            _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_k_nargout, 1U,
              c2_sf_marshallOut, c2_sf_marshallIn);
            _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_b_o_timestamp, 2U,
              c2_sf_marshallOut, c2_sf_marshallIn);
            _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 3U, chartInstance->c2_sfEvent);
            if (chartInstance->c2_AreListenersActive == 1) {
              sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 45,
                7);
            }

            c2_b_o_timestamp = _sfTime_;
            if (chartInstance->c2_AreListenersActive == 1) {
              sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 45, 7);
            }

            _SFD_SYMBOL_SCOPE_POP();
            _SFD_CS_CALL(FUNCTION_INACTIVE_TAG, 7U, chartInstance->c2_sfEvent);
            _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 7U, chartInstance->c2_sfEvent);
            if (chartInstance->c2_AreListenersActive == 1) {
              sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 43, 3);
            }

            *(real_T *)&((char_T *)chartInstance->c2_RBC_SEND_MA)[0] =
              c2_b_o_timestamp;
            _SFD_CM_CALL(MESSAGE_SEND_BREAKPOINT_TAG, 17U, (uint32_T)
                         chartInstance->c2_sfEvent);
            slMessageRtDiagnosticCheck
              (chartInstance->c2_RBC_SEND_MA_msgInterface, NULL, "OnSend", 67U,
               248, 17);
            c2_sf_msg_send_RBC_SEND_MA(chartInstance);
            if (chartInstance->c2_AreListenersActive == 1) {
              sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 67, 7);
            }

            _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 9U, chartInstance->c2_sfEvent);
            if (chartInstance->c2_AreListenersActive == 1) {
              sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 69,
                7);
            }

            if (chartInstance->c2_AreListenersActive == 1) {
              sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 69, 7);
            }
          } else {
            _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 10U, chartInstance->c2_sfEvent);
            if (chartInstance->c2_AreListenersActive == 1) {
              sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 70,
                7);
            }

            if (chartInstance->c2_AreListenersActive == 1) {
              sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 70, 6);
            }

            if (chartInstance->c2_AreListenersActive == 1) {
              sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 70, 7);
            }
          }

          _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 11U, chartInstance->c2_sfEvent);
          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 72, 7);
          }

          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 72, 7);
          }

          _SFD_SYMBOL_SCOPE_POP();
          _SFD_CS_CALL(FUNCTION_INACTIVE_TAG, 6U, chartInstance->c2_sfEvent);
          _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 6U, chartInstance->c2_sfEvent);
          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 61, 3);
          }

          _SFD_SYMBOL_SCOPE_POP();
          if (chartInstance->c2_AreListenersActive == 1) {
            sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 58, 2);
          }
        }
      }

      _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 5U, chartInstance->c2_sfEvent);
      break;

     default:
      CV_STATE_EVAL(2, 0, 0);

      /* Unreachable state, for coverage only */
      chartInstance->c2_is_RBC_MAIN = c2_IN_NO_ACTIVE_CHILD;
      _SFD_CS_CALL(STATE_INACTIVE_TAG, 3U, chartInstance->c2_sfEvent);
      break;
    }

    _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 2U, chartInstance->c2_sfEvent);
  }

  _SFD_CC_CALL(EXIT_OUT_OF_FUNCTION_TAG, 1U, chartInstance->c2_sfEvent);
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 0, 0);
  }
}

static void initSimStructsc2_moving_block_decomposed_msg_train
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void init_script_number_translation(uint32_T c2_machineNumber, uint32_T
  c2_chartNumber, uint32_T c2_instanceNumber)
{
  (void)(c2_machineNumber);
  (void)(c2_chartNumber);
  (void)(c2_instanceNumber);
}

static const mxArray *c2_sf_marshallOut(void *chartInstanceVoid, void *c2_inData)
{
  const mxArray *c2_mxArrayOutData;
  real_T c2_u;
  const mxArray *c2_y = NULL;
  SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance;
  chartInstance = (SFc2_moving_block_decomposed_msg_trainInstanceStruct *)
    chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  c2_mxArrayOutData = NULL;
  c2_u = *(real_T *)c2_inData;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", &c2_u, 0, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c2_mxArrayOutData, c2_y, false);
  return c2_mxArrayOutData;
}

static real_T c2_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_nargout, const char_T *c2_identifier)
{
  real_T c2_y;
  emlrtMsgIdentifier c2_thisId;
  c2_thisId.fIdentifier = (const char *)c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_nargout), &c2_thisId);
  sf_mex_destroy(&c2_nargout);
  return c2_y;
}

static real_T c2_b_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  real_T c2_y;
  real_T c2_d0;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_d0, 1, 0, 0U, 0, 0U, 0);
  c2_y = c2_d0;
  sf_mex_destroy(&c2_u);
  return c2_y;
}

static void c2_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData)
{
  const mxArray *c2_nargout;
  emlrtMsgIdentifier c2_thisId;
  real_T c2_y;
  SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance;
  chartInstance = (SFc2_moving_block_decomposed_msg_trainInstanceStruct *)
    chartInstanceVoid;
  c2_nargout = sf_mex_dup(c2_mxArrayInData);
  c2_thisId.fIdentifier = (const char *)c2_varName;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_nargout), &c2_thisId);
  sf_mex_destroy(&c2_nargout);
  *(real_T *)c2_outData = c2_y;
  sf_mex_destroy(&c2_mxArrayInData);
}

static const mxArray *c2_b_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData)
{
  const mxArray *c2_mxArrayOutData;
  boolean_T c2_u;
  const mxArray *c2_y = NULL;
  SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance;
  chartInstance = (SFc2_moving_block_decomposed_msg_trainInstanceStruct *)
    chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  c2_mxArrayOutData = NULL;
  c2_u = *(boolean_T *)c2_inData;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", &c2_u, 11, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c2_mxArrayOutData, c2_y, false);
  return c2_mxArrayOutData;
}

static boolean_T c2_c_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  boolean_T c2_y;
  boolean_T c2_b0;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_b0, 1, 11, 0U, 0, 0U, 0);
  c2_y = c2_b0;
  sf_mex_destroy(&c2_u);
  return c2_y;
}

static void c2_b_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData)
{
  const mxArray *c2_sf_internal_predicateOutput;
  emlrtMsgIdentifier c2_thisId;
  boolean_T c2_y;
  SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance;
  chartInstance = (SFc2_moving_block_decomposed_msg_trainInstanceStruct *)
    chartInstanceVoid;
  c2_sf_internal_predicateOutput = sf_mex_dup(c2_mxArrayInData);
  c2_thisId.fIdentifier = (const char *)c2_varName;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_c_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c2_sf_internal_predicateOutput), &c2_thisId);
  sf_mex_destroy(&c2_sf_internal_predicateOutput);
  *(boolean_T *)c2_outData = c2_y;
  sf_mex_destroy(&c2_mxArrayInData);
}

const mxArray
  *sf_c2_moving_block_decomposed_msg_train_get_eml_resolved_functions_info(void)
{
  const mxArray *c2_nameCaptureInfo = NULL;
  c2_nameCaptureInfo = NULL;
  sf_mex_assign(&c2_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1U, 0U, 2, 0, 1), false);
  return c2_nameCaptureInfo;
}

static void c2_initialize_message_queues_for_chart
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  chartInstance->c2_RBC_REC_location_msgInterface =
    slMessageRtRegisterInputMessageQueue(chartInstance->S, 0);
  chartInstance->c2_RBC_SEND_MA_msgInterface =
    slMessageRtRegisterOutputMessageQueue(chartInstance->S, 1);
  chartInstance->c2_MA_ACK_from_OBU_msgInterface =
    slMessageRtRegisterInputMessageQueue(chartInstance->S, 2);
}

static void c2_sf_msg_discard_RBC_REC_location
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  slMessageRtDestroyActiveMessageIfPresent
    (chartInstance->c2_RBC_REC_location_msgInterface);
}

static void c2_sf_msg_discard_MA_ACK_from_OBU
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  slMessageRtDestroyActiveMessageIfPresent
    (chartInstance->c2_MA_ACK_from_OBU_msgInterface);
}

static void c2_sf_msg_reset_message_has_been_sent_RBC_SEND_MA
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  slMessageRtResetMsgHasBeenSet(chartInstance->c2_RBC_SEND_MA_msgInterface);
}

static void c2_read_msg_queue
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  uint32_T c2_debug_family_var_map[2];
  real_T c2_nargin = 0.0;
  real_T c2_nargout = 0.0;
  boolean_T c2_sf_internal_predicateOutput;
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 77, 3);
  }

  _SFD_CS_CALL(FUNCTION_ACTIVE_TAG, 1U, chartInstance->c2_sfEvent);
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 2U, 2U, c2_debug_family_names,
    c2_debug_family_var_map);
  _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 1U, chartInstance->c2_sfEvent);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_nargin, 0U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_nargout, 1U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 13U, chartInstance->c2_sfEvent);
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 79, 7);
  }

  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 79, 7);
  }

  _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 14U, chartInstance->c2_sfEvent);
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 81, 6);
  }

  _SFD_CM_CALL(MESSAGE_REMOVE_BREAKPOINT_TAG, 15U, (uint32_T)
               chartInstance->c2_sfEvent);
  c2_sf_internal_predicateOutput = CV_EML_IF(14, 0, 0,
    c2_sf_msg_pop_RBC_REC_location(chartInstance));
  if (c2_sf_internal_predicateOutput) {
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 14U, chartInstance->c2_sfEvent);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 81, 7);
    }

    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 81, 6);
    }

    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 81, 7);
    }

    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 17U, chartInstance->c2_sfEvent);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 86, 7);
    }

    chartInstance->c2_RBC_REC_location_flg = 1.0;
    chartInstance->c2_dataWrittenToVector[2U] = true;
    chartInstance->c2_dataWrittenToVector[2U] = true;
    _SFD_DATA_RANGE_CHECK(chartInstance->c2_RBC_REC_location_flg, 3U);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 86, 7);
    }

    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 16U, chartInstance->c2_sfEvent);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 85, 7);
    }

    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 85, 7);
    }
  } else {
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 15U, chartInstance->c2_sfEvent);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 84, 7);
    }

    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 84, 6);
    }

    chartInstance->c2_RBC_REC_location_flg = 0.0;
    chartInstance->c2_dataWrittenToVector[2U] = true;
    chartInstance->c2_dataWrittenToVector[2U] = true;
    _SFD_DATA_RANGE_CHECK(chartInstance->c2_RBC_REC_location_flg, 3U);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 84, 7);
    }
  }

  _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 18U, chartInstance->c2_sfEvent);
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 88, 7);
  }

  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 88, 7);
  }

  _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 19U, chartInstance->c2_sfEvent);
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 90, 6);
  }

  _SFD_CM_CALL(MESSAGE_REMOVE_BREAKPOINT_TAG, 16U, (uint32_T)
               chartInstance->c2_sfEvent);
  c2_sf_internal_predicateOutput = CV_EML_IF(19, 0, 0,
    c2_sf_msg_pop_MA_ACK_from_OBU(chartInstance));
  if (c2_sf_internal_predicateOutput) {
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 19U, chartInstance->c2_sfEvent);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 90, 7);
    }

    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 90, 7);
    }

    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 20U, chartInstance->c2_sfEvent);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 92, 7);
    }

    chartInstance->c2_MA_ACK_from_OBU_flg = 1.0;
    chartInstance->c2_dataWrittenToVector[3U] = true;
    chartInstance->c2_dataWrittenToVector[3U] = true;
    _SFD_DATA_RANGE_CHECK(chartInstance->c2_MA_ACK_from_OBU_flg, 0U);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 92, 7);
    }

    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 21U, chartInstance->c2_sfEvent);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 94, 7);
    }

    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 94, 7);
    }
  } else {
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 22U, chartInstance->c2_sfEvent);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 95, 7);
    }

    chartInstance->c2_MA_ACK_from_OBU_flg = 0.0;
    chartInstance->c2_dataWrittenToVector[3U] = true;
    chartInstance->c2_dataWrittenToVector[3U] = true;
    _SFD_DATA_RANGE_CHECK(chartInstance->c2_MA_ACK_from_OBU_flg, 0U);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 95, 7);
    }
  }

  _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 23U, chartInstance->c2_sfEvent);
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 97, 7);
  }

  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 97, 7);
  }

  _SFD_SYMBOL_SCOPE_POP();
  _SFD_CS_CALL(FUNCTION_INACTIVE_TAG, 1U, chartInstance->c2_sfEvent);
  _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 1U, chartInstance->c2_sfEvent);
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 77, 3);
  }
}

static void c2_set_current_MA_value
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, real_T
   c2_i_OBU_location, real_T c2_i_previous_MA, real_T c2_i_previous_train_pos)
{
  uint32_T c2_debug_family_var_map[5];
  real_T c2_nargin = 3.0;
  real_T c2_nargout = 0.0;
  boolean_T c2_sf_internal_predicateOutput;
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 49, 3);
  }

  _SFD_CS_CALL(FUNCTION_ACTIVE_TAG, 8U, chartInstance->c2_sfEvent);
  _SFD_SYMBOL_SCOPE_PUSH_EML(0U, 5U, 5U, c2_c_debug_family_names,
    c2_debug_family_var_map);
  _SFD_CS_CALL(STATE_ENTER_DURING_FUNCTION_TAG, 8U, chartInstance->c2_sfEvent);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_nargin, 0U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_nargout, 1U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_i_OBU_location, 2U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_i_previous_MA, 3U, c2_sf_marshallOut,
    c2_sf_marshallIn);
  _SFD_SYMBOL_SCOPE_ADD_EML_IMPORTABLE(&c2_i_previous_train_pos, 4U,
    c2_sf_marshallOut, c2_sf_marshallIn);
  _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 4U, chartInstance->c2_sfEvent);
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 51, 7);
  }

  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 51, 7);
  }

  _SFD_CT_CALL(TRANSITION_BEFORE_PROCESSING_TAG, 24U, chartInstance->c2_sfEvent);
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 103, 6);
  }

  c2_sf_internal_predicateOutput = CV_EML_IF(24, 0, 0, CV_RELATIONAL_EVAL(5U,
    24U, 0, c2_i_OBU_location, c2_i_previous_MA + c2_i_previous_train_pos, -1,
    2U, c2_i_OBU_location < c2_i_previous_MA + c2_i_previous_train_pos));
  if (c2_sf_internal_predicateOutput) {
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 24U, chartInstance->c2_sfEvent);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 103, 7);
    }

    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 103, 6);
    }

    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 103, 7);
    }

    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 25U, chartInstance->c2_sfEvent);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 106, 7);
    }

    *(real_T *)&((char_T *)chartInstance->c2_RBC_SEND_MA)[16] = 1000.0;
    chartInstance->c2_previous_train_pos = c2_i_OBU_location;
    chartInstance->c2_dataWrittenToVector[4U] = true;
    chartInstance->c2_dataWrittenToVector[4U] = true;
    _SFD_DATA_RANGE_CHECK(chartInstance->c2_previous_train_pos, 7U);
    chartInstance->c2_previous_MA = *(real_T *)&((char_T *)
      chartInstance->c2_RBC_SEND_MA)[16];
    chartInstance->c2_dataWrittenToVector[5U] = true;
    chartInstance->c2_dataWrittenToVector[5U] = true;
    _SFD_DATA_RANGE_CHECK(chartInstance->c2_previous_MA, 6U);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 106, 7);
    }

    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 27U, chartInstance->c2_sfEvent);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 109, 7);
    }

    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 109, 7);
    }
  } else {
    _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 26U, chartInstance->c2_sfEvent);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 108, 7);
    }

    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 108, 6);
    }

    *(real_T *)&((char_T *)chartInstance->c2_RBC_SEND_MA)[16] = 0.0;
    chartInstance->c2_previous_train_pos = c2_const_INIT_TRAIN_POSITION_VALUE;
    chartInstance->c2_dataWrittenToVector[4U] = true;
    chartInstance->c2_dataWrittenToVector[4U] = true;
    _SFD_DATA_RANGE_CHECK(chartInstance->c2_previous_train_pos, 7U);
    chartInstance->c2_previous_MA = 0.0;
    chartInstance->c2_dataWrittenToVector[5U] = true;
    chartInstance->c2_dataWrittenToVector[5U] = true;
    _SFD_DATA_RANGE_CHECK(chartInstance->c2_previous_MA, 6U);
    if (chartInstance->c2_AreListenersActive == 1) {
      sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 108, 7);
    }
  }

  _SFD_CT_CALL(TRANSITION_ACTIVE_TAG, 28U, chartInstance->c2_sfEvent);
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportStartingSection(chartInstance->c2_RuntimeVar, 111, 7);
  }

  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 111, 7);
  }

  _SFD_SYMBOL_SCOPE_POP();
  _SFD_CS_CALL(FUNCTION_INACTIVE_TAG, 8U, chartInstance->c2_sfEvent);
  _SFD_CS_CALL(EXIT_OUT_OF_FUNCTION_TAG, 8U, chartInstance->c2_sfEvent);
  if (chartInstance->c2_AreListenersActive == 1) {
    sfListenerReportEndingSection(chartInstance->c2_RuntimeVar, 49, 3);
  }
}

static const mxArray *c2_c_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData)
{
  const mxArray *c2_mxArrayOutData;
  int32_T c2_u;
  const mxArray *c2_y = NULL;
  SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance;
  chartInstance = (SFc2_moving_block_decomposed_msg_trainInstanceStruct *)
    chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  c2_mxArrayOutData = NULL;
  c2_u = *(int32_T *)c2_inData;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", &c2_u, 6, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c2_mxArrayOutData, c2_y, false);
  return c2_mxArrayOutData;
}

static int32_T c2_d_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  int32_T c2_y;
  int32_T c2_i1;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_i1, 1, 6, 0U, 0, 0U, 0);
  c2_y = c2_i1;
  sf_mex_destroy(&c2_u);
  return c2_y;
}

static void c2_c_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData)
{
  const mxArray *c2_b_sfEvent;
  emlrtMsgIdentifier c2_thisId;
  int32_T c2_y;
  SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance;
  chartInstance = (SFc2_moving_block_decomposed_msg_trainInstanceStruct *)
    chartInstanceVoid;
  c2_b_sfEvent = sf_mex_dup(c2_mxArrayInData);
  c2_thisId.fIdentifier = (const char *)c2_varName;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_d_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_b_sfEvent),
    &c2_thisId);
  sf_mex_destroy(&c2_b_sfEvent);
  *(int32_T *)c2_outData = c2_y;
  sf_mex_destroy(&c2_mxArrayInData);
}

static const mxArray *c2_d_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData)
{
  const mxArray *c2_mxArrayOutData;
  uint8_T c2_u;
  const mxArray *c2_y = NULL;
  SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance;
  chartInstance = (SFc2_moving_block_decomposed_msg_trainInstanceStruct *)
    chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  c2_mxArrayOutData = NULL;
  c2_u = *(uint8_T *)c2_inData;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_create("y", &c2_u, 3, 0U, 0U, 0U, 0), false);
  sf_mex_assign(&c2_mxArrayOutData, c2_y, false);
  return c2_mxArrayOutData;
}

static uint8_T c2_e_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_b_tp_MESSAGE_QUEUE_MANAGER, const char_T *c2_identifier)
{
  uint8_T c2_y;
  emlrtMsgIdentifier c2_thisId;
  c2_thisId.fIdentifier = (const char *)c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c2_b_tp_MESSAGE_QUEUE_MANAGER), &c2_thisId);
  sf_mex_destroy(&c2_b_tp_MESSAGE_QUEUE_MANAGER);
  return c2_y;
}

static uint8_T c2_f_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  uint8_T c2_y;
  uint8_T c2_u0;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), &c2_u0, 1, 3, 0U, 0, 0U, 0);
  c2_y = c2_u0;
  sf_mex_destroy(&c2_u);
  return c2_y;
}

static void c2_d_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData)
{
  const mxArray *c2_b_tp_MESSAGE_QUEUE_MANAGER;
  emlrtMsgIdentifier c2_thisId;
  uint8_T c2_y;
  SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance;
  chartInstance = (SFc2_moving_block_decomposed_msg_trainInstanceStruct *)
    chartInstanceVoid;
  c2_b_tp_MESSAGE_QUEUE_MANAGER = sf_mex_dup(c2_mxArrayInData);
  c2_thisId.fIdentifier = (const char *)c2_varName;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c2_b_tp_MESSAGE_QUEUE_MANAGER), &c2_thisId);
  sf_mex_destroy(&c2_b_tp_MESSAGE_QUEUE_MANAGER);
  *(uint8_T *)c2_outData = c2_y;
  sf_mex_destroy(&c2_mxArrayInData);
}

static const mxArray *c2_RBC_SEND_MA_bus_io(void *chartInstanceVoid, void
  *c2_pData)
{
  const mxArray *c2_mxVal;
  c2_MA_msg c2_tmp;
  SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance;
  chartInstance = (SFc2_moving_block_decomposed_msg_trainInstanceStruct *)
    chartInstanceVoid;
  c2_mxVal = NULL;
  c2_mxVal = NULL;
  c2_tmp.MA_timestamp = *(real_T *)&((char_T *)(c2_MA_msg *)c2_pData)[0];
  c2_tmp.flg_new_MA = *(real_T *)&((char_T *)(c2_MA_msg *)c2_pData)[8];
  c2_tmp.MA_value = *(real_T *)&((char_T *)(c2_MA_msg *)c2_pData)[16];
  sf_mex_assign(&c2_mxVal, c2_e_sf_marshallOut(chartInstance, &c2_tmp), false);
  return c2_mxVal;
}

static const mxArray *c2_e_sf_marshallOut(void *chartInstanceVoid, void
  *c2_inData)
{
  const mxArray *c2_mxArrayOutData;
  c2_MA_msg c2_u;
  const mxArray *c2_y = NULL;
  real_T c2_b_u;
  const mxArray *c2_b_y = NULL;
  real_T c2_c_u;
  const mxArray *c2_c_y = NULL;
  real_T c2_d_u;
  const mxArray *c2_d_y = NULL;
  SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance;
  chartInstance = (SFc2_moving_block_decomposed_msg_trainInstanceStruct *)
    chartInstanceVoid;
  c2_mxArrayOutData = NULL;
  c2_mxArrayOutData = NULL;
  c2_u = *(c2_MA_msg *)c2_inData;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_createstruct("structure", 2, 1, 1), false);
  c2_b_u = c2_u.MA_timestamp;
  c2_b_y = NULL;
  sf_mex_assign(&c2_b_y, sf_mex_create("y", &c2_b_u, 0, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c2_y, c2_b_y, "MA_timestamp", "MA_timestamp", 0);
  c2_c_u = c2_u.flg_new_MA;
  c2_c_y = NULL;
  sf_mex_assign(&c2_c_y, sf_mex_create("y", &c2_c_u, 0, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c2_y, c2_c_y, "flg_new_MA", "flg_new_MA", 0);
  c2_d_u = c2_u.MA_value;
  c2_d_y = NULL;
  sf_mex_assign(&c2_d_y, sf_mex_create("y", &c2_d_u, 0, 0U, 0U, 0U, 0), false);
  sf_mex_addfield(c2_y, c2_d_y, "MA_value", "MA_value", 0);
  sf_mex_assign(&c2_mxArrayOutData, c2_y, false);
  return c2_mxArrayOutData;
}

static c2_MA_msg c2_g_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  c2_MA_msg c2_y;
  emlrtMsgIdentifier c2_thisId;
  static const char * c2_fieldNames[3] = { "MA_timestamp", "flg_new_MA",
    "MA_value" };

  c2_thisId.fParent = c2_parentId;
  c2_thisId.bParentIsCell = false;
  sf_mex_check_struct(c2_parentId, c2_u, 3, c2_fieldNames, 0U, NULL);
  c2_thisId.fIdentifier = "MA_timestamp";
  c2_y.MA_timestamp = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c2_u, "MA_timestamp", "MA_timestamp", 0)), &c2_thisId);
  c2_thisId.fIdentifier = "flg_new_MA";
  c2_y.flg_new_MA = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c2_u, "flg_new_MA", "flg_new_MA", 0)), &c2_thisId);
  c2_thisId.fIdentifier = "MA_value";
  c2_y.MA_value = c2_b_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getfield(c2_u, "MA_value", "MA_value", 0)), &c2_thisId);
  sf_mex_destroy(&c2_u);
  return c2_y;
}

static void c2_e_sf_marshallIn(void *chartInstanceVoid, const mxArray
  *c2_mxArrayInData, const char_T *c2_varName, void *c2_outData)
{
  const mxArray *c2_b_RBC_SEND_MA;
  emlrtMsgIdentifier c2_thisId;
  c2_MA_msg c2_y;
  SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance;
  chartInstance = (SFc2_moving_block_decomposed_msg_trainInstanceStruct *)
    chartInstanceVoid;
  c2_b_RBC_SEND_MA = sf_mex_dup(c2_mxArrayInData);
  c2_thisId.fIdentifier = (const char *)c2_varName;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_y = c2_g_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_b_RBC_SEND_MA),
    &c2_thisId);
  sf_mex_destroy(&c2_b_RBC_SEND_MA);
  *(c2_MA_msg *)c2_outData = c2_y;
  sf_mex_destroy(&c2_mxArrayInData);
}

static void c2_h_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_b_dataWrittenToVector, const char_T *c2_identifier, boolean_T
   c2_y[9])
{
  emlrtMsgIdentifier c2_thisId;
  c2_thisId.fIdentifier = (const char *)c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  c2_i_emlrt_marshallIn(chartInstance, sf_mex_dup(c2_b_dataWrittenToVector),
                        &c2_thisId, c2_y);
  sf_mex_destroy(&c2_b_dataWrittenToVector);
}

static void c2_i_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId, boolean_T c2_y[9])
{
  boolean_T c2_bv1[9];
  int32_T c2_i2;
  (void)chartInstance;
  sf_mex_import(c2_parentId, sf_mex_dup(c2_u), c2_bv1, 1, 11, 0U, 1, 0U, 1, 9);
  for (c2_i2 = 0; c2_i2 < 9; c2_i2++) {
    c2_y[c2_i2] = c2_bv1[c2_i2];
  }

  sf_mex_destroy(&c2_u);
}

static const mxArray *c2_j_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_b_setSimStateSideEffectsInfo, const char_T *c2_identifier)
{
  const mxArray *c2_y = NULL;
  emlrtMsgIdentifier c2_thisId;
  c2_y = NULL;
  c2_thisId.fIdentifier = (const char *)c2_identifier;
  c2_thisId.fParent = NULL;
  c2_thisId.bParentIsCell = false;
  sf_mex_assign(&c2_y, c2_k_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c2_b_setSimStateSideEffectsInfo), &c2_thisId), false);
  sf_mex_destroy(&c2_b_setSimStateSideEffectsInfo);
  return c2_y;
}

static const mxArray *c2_k_emlrt_marshallIn
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, const
   mxArray *c2_u, const emlrtMsgIdentifier *c2_parentId)
{
  const mxArray *c2_y = NULL;
  (void)chartInstance;
  (void)c2_parentId;
  c2_y = NULL;
  sf_mex_assign(&c2_y, sf_mex_duplicatearraysafe(&c2_u), false);
  sf_mex_destroy(&c2_u);
  return c2_y;
}

static void c2_cleanup_message_queues_for_chart
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  slMessageRtDestroyQueue(chartInstance->c2_RBC_REC_location_msgInterface);
  slMessageRtDestroyQueue(chartInstance->c2_RBC_SEND_MA_msgInterface);
  slMessageRtDestroyQueue(chartInstance->c2_MA_ACK_from_OBU_msgInterface);
}

static const mxArray *c2_getMsgInfoFor_RBC_REC_location
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  const mxArray *c2_msgInfo;
  int32_T c2_i3;
  const mxArray *c2_isPopped = NULL;
  int32_T c2_i4;
  const mxArray *c2_isForwarded = NULL;
  const mxArray *c2_m0 = NULL;
  int32_T c2_numMsgsInQ;
  const mxArray *c2_numMsgsInQ_mx = NULL;
  const mxArray *c2_payloads = NULL;
  int32_T c2_msgIndex;
  c2_PR_msg *c2_payloadValue;
  c2_PR_msg c2_b_payloadValue;
  const mxArray *c2_m1 = NULL;
  const mxArray *c2_payloadValue_mx = NULL;
  c2_msgInfo = NULL;
  c2_msgInfo = NULL;
  sf_mex_assign(&c2_msgInfo, mxCreateStructMatrix_wrapper(1, 1, 5, c2_sv0),
                false);
  c2_i3 = slMessageRtIsMessageValid
    (chartInstance->c2_RBC_REC_location_msgInterface);
  sf_mex_assign(&c2_isPopped, sf_mex_create("isPopped", &c2_i3, 6, 0U, 0U, 0U, 0),
                false);
  sf_mex_setfield(c2_msgInfo, 0, "isPopped", sf_mex_dup(c2_isPopped));
  c2_i4 = slMessageRtHasMessageBeenForwarded
    (chartInstance->c2_RBC_REC_location_msgInterface);
  sf_mex_assign(&c2_isForwarded, sf_mex_create("isForwarded", &c2_i4, 6, 0U, 0U,
    0U, 0), false);
  sf_mex_setfield(c2_msgInfo, 0, "isForwarded", sf_mex_dup(c2_isForwarded));
  if (slMessageRtIsMessageValid(chartInstance->c2_RBC_REC_location_msgInterface)
      || slMessageRtHasMessageBeenForwarded
      (chartInstance->c2_RBC_REC_location_msgInterface)) {
    c2_m0 = NULL;
    sf_mex_assign(&c2_m0, sf_mex_createstruct("sf_mex_setfield", 0), false);
    sf_mex_addfield(c2_m0, sf_mex_create("sf_mex_setfield", (real_T *)&((char_T *)
      (c2_PR_msg *)chartInstance->c2_RBC_REC_location_msgDataPtr)[0], 0, 0U, 0U,
      0U, 0), "current_location", "sf_mex_setfield", 0);
    sf_mex_addfield(c2_m0, sf_mex_create("sf_mex_setfield", (real_T *)&((char_T *)
      (c2_PR_msg *)chartInstance->c2_RBC_REC_location_msgDataPtr)[8], 0, 0U, 0U,
      0U, 0), "current_timestamp", "sf_mex_setfield", 0);
    sf_mex_setfield(c2_msgInfo, 0, "payload", c2_m0);
  } else {
    sf_mex_setfield(c2_msgInfo, 0, "payload", sf_mex_createcellmatrix(0, 0));
  }

  c2_numMsgsInQ = slMessageRtLength
    (chartInstance->c2_RBC_REC_location_msgInterface);
  sf_mex_assign(&c2_numMsgsInQ_mx, sf_mex_create("numMsgsInQ_mx", &c2_numMsgsInQ,
    6, 0U, 0U, 0U, 0), false);
  sf_mex_setfield(c2_msgInfo, 0, "numPayloadsInQ", sf_mex_dup(c2_numMsgsInQ_mx));
  sf_mex_assign(&c2_payloads, sf_mex_createcellmatrix(1, c2_numMsgsInQ), false);
  for (c2_msgIndex = 0; c2_msgIndex < c2_numMsgsInQ; c2_msgIndex++) {
    c2_payloadValue = (c2_PR_msg *)slMessageRtPeekAtIndex
      (chartInstance->c2_RBC_REC_location_msgInterface, c2_msgIndex);
    c2_b_payloadValue = *c2_payloadValue;
    c2_m1 = NULL;
    sf_mex_assign(&c2_m1, sf_mex_createstruct("payloadValue_mx", 0), false);
    sf_mex_addfield(c2_m1, sf_mex_create("payloadValue_mx",
      &c2_b_payloadValue.current_location, 0, 0U, 0U, 0U, 0), "current_location",
                    "payloadValue_mx", 0);
    sf_mex_addfield(c2_m1, sf_mex_create("payloadValue_mx",
      &c2_b_payloadValue.current_timestamp, 0, 0U, 0U, 0U, 0),
                    "current_timestamp", "payloadValue_mx", 0);
    sf_mex_assign(&c2_payloadValue_mx, c2_m1, false);
    sf_mex_setcell(c2_payloads, c2_msgIndex, sf_mex_dup(c2_payloadValue_mx));
  }

  sf_mex_setfield(c2_msgInfo, 0, "payloadsInQ", sf_mex_dup(c2_payloads));
  sf_mex_destroy(&c2_isPopped);
  sf_mex_destroy(&c2_isForwarded);
  sf_mex_destroy(&c2_numMsgsInQ_mx);
  sf_mex_destroy(&c2_payloads);
  sf_mex_destroy(&c2_payloadValue_mx);
  return c2_msgInfo;
}

static const mxArray *c2_getMsgInfoFor_RBC_SEND_MA
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  const mxArray *c2_msgInfo;
  const char * c2_msg_info_field_names[3] = { "payload", "numPayloadsInQ",
    "payloadsInQ" };

  const mxArray *c2_m2 = NULL;
  int32_T c2_numMsgsInQ;
  const mxArray *c2_numMsgsInQ_mx = NULL;
  const mxArray *c2_payloads = NULL;
  int32_T c2_msgIndex;
  c2_MA_msg *c2_payloadValue;
  c2_MA_msg c2_b_payloadValue;
  const mxArray *c2_m3 = NULL;
  const mxArray *c2_payloadValue_mx = NULL;
  c2_msgInfo = NULL;
  c2_msgInfo = NULL;
  sf_mex_assign(&c2_msgInfo, mxCreateStructMatrix_wrapper(1, 1, 3,
    c2_msg_info_field_names), false);
  c2_m2 = NULL;
  sf_mex_assign(&c2_m2, sf_mex_createstruct("sf_mex_setfield", 0), false);
  sf_mex_addfield(c2_m2, sf_mex_create("sf_mex_setfield", (real_T *)&((char_T *)
    chartInstance->c2_RBC_SEND_MA)[0], 0, 0U, 0U, 0U, 0), "MA_timestamp",
                  "sf_mex_setfield", 0);
  sf_mex_addfield(c2_m2, sf_mex_create("sf_mex_setfield", (real_T *)&((char_T *)
    chartInstance->c2_RBC_SEND_MA)[8], 0, 0U, 0U, 0U, 0), "flg_new_MA",
                  "sf_mex_setfield", 0);
  sf_mex_addfield(c2_m2, sf_mex_create("sf_mex_setfield", (real_T *)&((char_T *)
    chartInstance->c2_RBC_SEND_MA)[16], 0, 0U, 0U, 0U, 0), "MA_value",
                  "sf_mex_setfield", 0);
  sf_mex_setfield(c2_msgInfo, 0, "payload", c2_m2);
  c2_numMsgsInQ = slMessageRtLength(chartInstance->c2_RBC_SEND_MA_msgInterface);
  sf_mex_assign(&c2_numMsgsInQ_mx, sf_mex_create("numMsgsInQ_mx", &c2_numMsgsInQ,
    6, 0U, 0U, 0U, 0), false);
  sf_mex_setfield(c2_msgInfo, 0, "numPayloadsInQ", sf_mex_dup(c2_numMsgsInQ_mx));
  sf_mex_assign(&c2_payloads, sf_mex_createcellmatrix(1, c2_numMsgsInQ), false);
  for (c2_msgIndex = 0; c2_msgIndex < c2_numMsgsInQ; c2_msgIndex++) {
    c2_payloadValue = (c2_MA_msg *)slMessageRtPeekAtIndex
      (chartInstance->c2_RBC_SEND_MA_msgInterface, c2_msgIndex);
    c2_b_payloadValue = *c2_payloadValue;
    c2_m3 = NULL;
    sf_mex_assign(&c2_m3, sf_mex_createstruct("payloadValue_mx", 0), false);
    sf_mex_addfield(c2_m3, sf_mex_create("payloadValue_mx",
      &c2_b_payloadValue.MA_timestamp, 0, 0U, 0U, 0U, 0), "MA_timestamp",
                    "payloadValue_mx", 0);
    sf_mex_addfield(c2_m3, sf_mex_create("payloadValue_mx",
      &c2_b_payloadValue.flg_new_MA, 0, 0U, 0U, 0U, 0), "flg_new_MA",
                    "payloadValue_mx", 0);
    sf_mex_addfield(c2_m3, sf_mex_create("payloadValue_mx",
      &c2_b_payloadValue.MA_value, 0, 0U, 0U, 0U, 0), "MA_value",
                    "payloadValue_mx", 0);
    sf_mex_assign(&c2_payloadValue_mx, c2_m3, false);
    sf_mex_setcell(c2_payloads, c2_msgIndex, sf_mex_dup(c2_payloadValue_mx));
  }

  sf_mex_setfield(c2_msgInfo, 0, "payloadsInQ", sf_mex_dup(c2_payloads));
  sf_mex_destroy(&c2_numMsgsInQ_mx);
  sf_mex_destroy(&c2_payloads);
  sf_mex_destroy(&c2_payloadValue_mx);
  return c2_msgInfo;
}

static const mxArray *c2_getMsgInfoFor_MA_ACK_from_OBU
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  const mxArray *c2_msgInfo;
  int32_T c2_i5;
  const mxArray *c2_isPopped = NULL;
  int32_T c2_i6;
  const mxArray *c2_isForwarded = NULL;
  real_T c2_d1;
  int32_T c2_numMsgsInQ;
  const mxArray *c2_numMsgsInQ_mx = NULL;
  const mxArray *c2_payloads = NULL;
  int32_T c2_msgIndex;
  real_T *c2_payloadValue;
  real_T c2_b_payloadValue;
  const mxArray *c2_payloadValue_mx = NULL;
  c2_msgInfo = NULL;
  c2_msgInfo = NULL;
  sf_mex_assign(&c2_msgInfo, mxCreateStructMatrix_wrapper(1, 1, 5, c2_sv0),
                false);
  c2_i5 = slMessageRtIsMessageValid
    (chartInstance->c2_MA_ACK_from_OBU_msgInterface);
  sf_mex_assign(&c2_isPopped, sf_mex_create("isPopped", &c2_i5, 6, 0U, 0U, 0U, 0),
                false);
  sf_mex_setfield(c2_msgInfo, 0, "isPopped", sf_mex_dup(c2_isPopped));
  c2_i6 = slMessageRtHasMessageBeenForwarded
    (chartInstance->c2_MA_ACK_from_OBU_msgInterface);
  sf_mex_assign(&c2_isForwarded, sf_mex_create("isForwarded", &c2_i6, 6, 0U, 0U,
    0U, 0), false);
  sf_mex_setfield(c2_msgInfo, 0, "isForwarded", sf_mex_dup(c2_isForwarded));
  if (slMessageRtIsMessageValid(chartInstance->c2_MA_ACK_from_OBU_msgInterface) ||
      slMessageRtHasMessageBeenForwarded
      (chartInstance->c2_MA_ACK_from_OBU_msgInterface)) {
    c2_d1 = *(real_T *)chartInstance->c2_MA_ACK_from_OBU_msgDataPtr;
    sf_mex_setfield(c2_msgInfo, 0, "payload", sf_mex_create("sf_mex_setfield",
      &c2_d1, 0, 0U, 0U, 0U, 0));
  } else {
    sf_mex_setfield(c2_msgInfo, 0, "payload", sf_mex_createcellmatrix(0, 0));
  }

  c2_numMsgsInQ = slMessageRtLength
    (chartInstance->c2_MA_ACK_from_OBU_msgInterface);
  sf_mex_assign(&c2_numMsgsInQ_mx, sf_mex_create("numMsgsInQ_mx", &c2_numMsgsInQ,
    6, 0U, 0U, 0U, 0), false);
  sf_mex_setfield(c2_msgInfo, 0, "numPayloadsInQ", sf_mex_dup(c2_numMsgsInQ_mx));
  sf_mex_assign(&c2_payloads, sf_mex_createcellmatrix(1, c2_numMsgsInQ), false);
  for (c2_msgIndex = 0; c2_msgIndex < c2_numMsgsInQ; c2_msgIndex++) {
    c2_payloadValue = (real_T *)slMessageRtPeekAtIndex
      (chartInstance->c2_MA_ACK_from_OBU_msgInterface, c2_msgIndex);
    c2_b_payloadValue = *c2_payloadValue;
    sf_mex_assign(&c2_payloadValue_mx, sf_mex_create("payloadValue_mx",
      &c2_b_payloadValue, 0, 0U, 0U, 0U, 0), false);
    sf_mex_setcell(c2_payloads, c2_msgIndex, sf_mex_dup(c2_payloadValue_mx));
  }

  sf_mex_setfield(c2_msgInfo, 0, "payloadsInQ", sf_mex_dup(c2_payloads));
  sf_mex_destroy(&c2_isPopped);
  sf_mex_destroy(&c2_isForwarded);
  sf_mex_destroy(&c2_numMsgsInQ_mx);
  sf_mex_destroy(&c2_payloads);
  sf_mex_destroy(&c2_payloadValue_mx);
  return c2_msgInfo;
}

static const mxArray *sf_get_hover_data_for_msg
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance, int32_T
   c2_ssid)
{
  const mxArray *c2_msgInfo = NULL;
  c2_msgInfo = NULL;
  if (c2_ssid == -1) {
  } else if (c2_ssid == 37) {
    sf_mex_assign(&c2_msgInfo, c2_getMsgInfoFor_RBC_REC_location(chartInstance),
                  false);
  } else if (c2_ssid == 38) {
    sf_mex_assign(&c2_msgInfo, c2_getMsgInfoFor_RBC_SEND_MA(chartInstance),
                  false);
  } else {
    if (c2_ssid == 57) {
      sf_mex_assign(&c2_msgInfo, c2_getMsgInfoFor_MA_ACK_from_OBU(chartInstance),
                    false);
    }
  }

  return c2_msgInfo;
}

static void c2_sf_msg_send_RBC_SEND_MA
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  slMessageRtSend(chartInstance->c2_RBC_SEND_MA_msgInterface,
                  chartInstance->c2_RBC_SEND_MA);
}

static boolean_T c2_sf_msg_pop_RBC_REC_location
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  boolean_T c2_isPresent;
  int32_T c2_status;
  if (!slMessageRtIsMessageValid(chartInstance->c2_RBC_REC_location_msgInterface))
  {
    c2_status = slMessageRtReceive
      (chartInstance->c2_RBC_REC_location_msgInterface,
       &chartInstance->c2_RBC_REC_location_msgDataPtr);
    if (slMessageRtMessageWasPopped(c2_status)) {
      c2_isPresent = true;
    } else {
      c2_isPresent = false;
    }
  } else {
    c2_isPresent = true;
  }

  return c2_isPresent;
}

static boolean_T c2_sf_msg_pop_MA_ACK_from_OBU
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  boolean_T c2_isPresent;
  int32_T c2_status;
  if (!slMessageRtIsMessageValid(chartInstance->c2_MA_ACK_from_OBU_msgInterface))
  {
    c2_status = slMessageRtReceive
      (chartInstance->c2_MA_ACK_from_OBU_msgInterface,
       &chartInstance->c2_MA_ACK_from_OBU_msgDataPtr);
    if (slMessageRtMessageWasPopped(c2_status)) {
      c2_isPresent = true;
    } else {
      c2_isPresent = false;
    }
  } else {
    c2_isPresent = true;
  }

  return c2_isPresent;
}

static void c2_init_sf_message_store_memory
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void init_dsm_address_info
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void init_simulink_io_address
  (SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance)
{
  chartInstance->c2_fEmlrtCtx = (void *)sfrtGetEmlrtCtx(chartInstance->S);
  chartInstance->c2_RBC_SEND_MA = (c2_MA_msg *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 1);
  chartInstance->c2_RBC_fail = (uint8_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 1);
}

/* SFunction Glue Code */
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

void sf_c2_moving_block_decomposed_msg_train_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(1086303393U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(1192458567U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(935902045U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(4013898570U);
}

mxArray* sf_c2_moving_block_decomposed_msg_train_get_post_codegen_info(void);
mxArray *sf_c2_moving_block_decomposed_msg_train_get_autoinheritance_info(void)
{
  const char *autoinheritanceFields[] = { "checksum", "inputs", "parameters",
    "outputs", "locals", "postCodegenInfo" };

  mxArray *mxAutoinheritanceInfo = mxCreateStructMatrix(1, 1, sizeof
    (autoinheritanceFields)/sizeof(autoinheritanceFields[0]),
    autoinheritanceFields);

  {
    mxArray *mxChecksum = mxCreateString("IMCTXRcOdIoaQ6emZZMRBH");
    mxSetField(mxAutoinheritanceInfo,0,"checksum",mxChecksum);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,3,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(13));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(3));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"inputs",mxData);
  }

  {
    mxSetField(mxAutoinheritanceInfo,0,"parameters",mxCreateDoubleMatrix(0,0,
                mxREAL));
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,1,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(13));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"outputs",mxData);
  }

  {
    const char *dataFields[] = { "size", "type", "complexity" };

    mxArray *mxData = mxCreateStructMatrix(1,8,3,dataFields);

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,0,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,0,"type",mxType);
    }

    mxSetField(mxData,0,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,1,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,1,"type",mxType);
    }

    mxSetField(mxData,1,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,2,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,2,"type",mxType);
    }

    mxSetField(mxData,2,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,3,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,3,"type",mxType);
    }

    mxSetField(mxData,3,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,4,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,4,"type",mxType);
    }

    mxSetField(mxData,4,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,5,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,5,"type",mxType);
    }

    mxSetField(mxData,5,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,6,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,6,"type",mxType);
    }

    mxSetField(mxData,6,"complexity",mxCreateDoubleScalar(0));

    {
      mxArray *mxSize = mxCreateDoubleMatrix(1,0,mxREAL);
      double *pr = mxGetPr(mxSize);
      mxSetField(mxData,7,"size",mxSize);
    }

    {
      const char *typeFields[] = { "base", "fixpt", "isFixedPointType" };

      mxArray *mxType = mxCreateStructMatrix(1,1,sizeof(typeFields)/sizeof
        (typeFields[0]),typeFields);
      mxSetField(mxType,0,"base",mxCreateDoubleScalar(10));
      mxSetField(mxType,0,"fixpt",mxCreateDoubleMatrix(0,0,mxREAL));
      mxSetField(mxType,0,"isFixedPointType",mxCreateDoubleScalar(0));
      mxSetField(mxData,7,"type",mxType);
    }

    mxSetField(mxData,7,"complexity",mxCreateDoubleScalar(0));
    mxSetField(mxAutoinheritanceInfo,0,"locals",mxData);
  }

  {
    mxArray* mxPostCodegenInfo =
      sf_c2_moving_block_decomposed_msg_train_get_post_codegen_info();
    mxSetField(mxAutoinheritanceInfo,0,"postCodegenInfo",mxPostCodegenInfo);
  }

  return(mxAutoinheritanceInfo);
}

mxArray *sf_c2_moving_block_decomposed_msg_train_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

mxArray *sf_c2_moving_block_decomposed_msg_train_jit_fallback_info(void)
{
  const char *infoFields[] = { "fallbackType", "fallbackReason",
    "hiddenFallbackType", "hiddenFallbackReason", "incompatibleSymbol" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 5, infoFields);
  mxArray *fallbackType = mxCreateString("pre");
  mxArray *fallbackReason = mxCreateString("hasBreakpoints");
  mxArray *hiddenFallbackType = mxCreateString("none");
  mxArray *hiddenFallbackReason = mxCreateString("");
  mxArray *incompatibleSymbol = mxCreateString("");
  mxSetField(mxInfo, 0, infoFields[0], fallbackType);
  mxSetField(mxInfo, 0, infoFields[1], fallbackReason);
  mxSetField(mxInfo, 0, infoFields[2], hiddenFallbackType);
  mxSetField(mxInfo, 0, infoFields[3], hiddenFallbackReason);
  mxSetField(mxInfo, 0, infoFields[4], incompatibleSymbol);
  return mxInfo;
}

mxArray *sf_c2_moving_block_decomposed_msg_train_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = mxCreateCellMatrix(1,0);
  return mxBIArgs;
}

mxArray* sf_c2_moving_block_decomposed_msg_train_get_post_codegen_info(void)
{
  const char* fieldNames[] = { "exportedFunctionsUsedByThisChart",
    "exportedFunctionsChecksum" };

  mwSize dims[2] = { 1, 1 };

  mxArray* mxPostCodegenInfo = mxCreateStructArray(2, dims, sizeof(fieldNames)/
    sizeof(fieldNames[0]), fieldNames);

  {
    mxArray* mxExportedFunctionsChecksum = mxCreateString("");
    mwSize exp_dims[2] = { 0, 1 };

    mxArray* mxExportedFunctionsUsedByThisChart = mxCreateCellArray(2, exp_dims);
    mxSetField(mxPostCodegenInfo, 0, "exportedFunctionsUsedByThisChart",
               mxExportedFunctionsUsedByThisChart);
    mxSetField(mxPostCodegenInfo, 0, "exportedFunctionsChecksum",
               mxExportedFunctionsChecksum);
  }

  return mxPostCodegenInfo;
}

static const mxArray *sf_get_sim_state_info_c2_moving_block_decomposed_msg_train
  (void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  const char *infoEncStr[] = {
    "100 S1x10'type','srcId','name','auxInfo'{{M[3],M[101],T\"MA_ACK_from_OBU_flg\",},{M[3],M[121],T\"OBU_current_location\",},{M[3],M[120],T\"OBU_current_timestamp\",},{M[3],M[100],T\"RBC_REC_location_flg\",},{M[3],M[75],T\"l_count_MA_sent\",},{M[3],M[74],T\"l_timeref_last_MA_sent\",},{M[3],M[116],T\"previous_MA\",},{M[3],M[115],T\"previous_train_pos\",},{M[8],M[0],T\"is_active_c2_moving_block_decomposed_msg_train\",},{M[8],M[22],T\"is_active_RBC_MAIN\",}}",
    "100 S1x3'type','srcId','name','auxInfo'{{M[8],M[76],T\"is_active_MESSAGE_QUEUE_MANAGER\",},{M[9],M[22],T\"is_RBC_MAIN\",},{M[15],M[0],T\"dataWrittenToVector\",}}"
  };

  mxArray *mxVarInfo = sf_mex_decode_encoded_mx_struct_array(infoEncStr, 13, 10);
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c2_moving_block_decomposed_msg_train_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static const mxArray* sf_opaque_get_hover_data_for_msg(void* chartInstance,
  int32_T msgSSID)
{
  return sf_get_hover_data_for_msg
    ( (SFc2_moving_block_decomposed_msg_trainInstanceStruct *) chartInstance,
     msgSSID);
}

static void chart_debug_initialization(SimStruct *S, unsigned int
  fullDebuggerInitialization)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance =
      (SFc2_moving_block_decomposed_msg_trainInstanceStruct *)
      sf_get_chart_instance_ptr(S);
    if (ssIsFirstInitCond(S) && fullDebuggerInitialization==1) {
      /* do this only if simulation is starting */
      {
        unsigned int chartAlreadyPresent;
        chartAlreadyPresent = sf_debug_initialize_chart
          (sfGlobalDebugInstanceStruct,
           _moving_block_decomposed_msg_trainMachineNumber_,
           2,
           9,
           29,
           3,
           18,
           0,
           0,
           0,
           0,
           0,
           &chartInstance->chartNumber,
           &chartInstance->instanceNumber,
           (void *)S);

        /* Each instance must initialize its own list of scripts */
        init_script_number_translation
          (_moving_block_decomposed_msg_trainMachineNumber_,
           chartInstance->chartNumber,chartInstance->instanceNumber);
        if (chartAlreadyPresent==0) {
          /* this is the first instance */
          sf_debug_set_chart_disable_implicit_casting
            (sfGlobalDebugInstanceStruct,
             _moving_block_decomposed_msg_trainMachineNumber_,
             chartInstance->chartNumber,1);
          sf_debug_set_chart_event_thresholds(sfGlobalDebugInstanceStruct,
            _moving_block_decomposed_msg_trainMachineNumber_,
            chartInstance->chartNumber,
            0,
            0,
            0);
          _SFD_SET_DATA_PROPS(0,0,0,0,"MA_ACK_from_OBU_flg");
          _SFD_SET_DATA_PROPS(1,0,0,0,"OBU_current_location");
          _SFD_SET_DATA_PROPS(2,0,0,0,"OBU_current_timestamp");
          _SFD_SET_DATA_PROPS(3,0,0,0,"RBC_REC_location_flg");
          _SFD_SET_DATA_PROPS(4,0,0,0,"l_count_MA_sent");
          _SFD_SET_DATA_PROPS(5,0,0,0,"l_timeref_last_MA_sent");
          _SFD_SET_DATA_PROPS(6,0,0,0,"previous_MA");
          _SFD_SET_DATA_PROPS(7,0,0,0,"previous_train_pos");
          _SFD_SET_DATA_PROPS(15,1,1,0,"RBC_REC_location");
          _SFD_SET_DATA_PROPS(8,1,1,0,"RBC_fail");
          _SFD_SET_DATA_PROPS(16,1,1,0,"MA_ACK_from_OBU");
          _SFD_SET_DATA_PROPS(17,2,0,1,"RBC_SEND_MA");
          _SFD_SET_DATA_PROPS(9,7,0,0,"INIT_TRAIN_POSITION_VALUE");
          _SFD_SET_DATA_PROPS(10,8,0,0,"");
          _SFD_SET_DATA_PROPS(11,8,0,0,"");
          _SFD_SET_DATA_PROPS(12,8,0,0,"");
          _SFD_SET_DATA_PROPS(13,8,0,0,"");
          _SFD_SET_DATA_PROPS(14,9,0,0,"");
          _SFD_STATE_INFO(0,0,1);
          _SFD_STATE_INFO(2,0,1);
          _SFD_STATE_INFO(3,0,0);
          _SFD_STATE_INFO(4,0,0);
          _SFD_STATE_INFO(5,0,0);
          _SFD_STATE_INFO(1,0,2);
          _SFD_STATE_INFO(6,0,2);
          _SFD_STATE_INFO(7,0,2);
          _SFD_STATE_INFO(8,0,2);
          _SFD_CH_SUBSTATE_COUNT(2);
          _SFD_CH_SUBSTATE_DECOMP(1);
          _SFD_CH_SUBSTATE_INDEX(0,0);
          _SFD_CH_SUBSTATE_INDEX(1,2);
          _SFD_ST_SUBSTATE_COUNT(0,0);
          _SFD_ST_SUBSTATE_COUNT(2,3);
          _SFD_ST_SUBSTATE_INDEX(2,0,3);
          _SFD_ST_SUBSTATE_INDEX(2,1,4);
          _SFD_ST_SUBSTATE_INDEX(2,2,5);
          _SFD_ST_SUBSTATE_COUNT(3,0);
          _SFD_ST_SUBSTATE_COUNT(4,0);
          _SFD_ST_SUBSTATE_COUNT(5,0);
        }

        _SFD_CV_INIT_CHART(2,0,0,0);

        {
          _SFD_CV_INIT_STATE(0,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(2,3,1,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(3,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(4,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(5,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(1,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(6,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(7,0,0,0,0,0,NULL,NULL);
        }

        {
          _SFD_CV_INIT_STATE(8,0,0,0,0,0,NULL,NULL);
        }

        _SFD_CV_INIT_TRANS(13,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(14,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(15,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(17,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(16,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(18,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(19,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(22,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(20,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(21,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(23,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(0,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(1,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(12,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(2,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(5,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(6,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(7,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(10,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(8,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(9,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(11,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(4,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(24,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(26,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(25,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(27,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(28,0,NULL,NULL,0,NULL);
        _SFD_CV_INIT_TRANS(3,0,NULL,NULL,0,NULL);

        /* Initialization of MATLAB Function Model Coverage */
        _SFD_CV_INIT_EML(0,1,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(2,1,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(5,1,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(13,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(14,0,0,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(14,0,0,0,16,0,16);
        _SFD_CV_INIT_EML(15,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(17,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(16,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(18,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(19,0,0,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(19,0,0,0,15,0,15);
        _SFD_CV_INIT_EML(22,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(20,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(21,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(23,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(6,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(7,0,0,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(7,0,0,1,31,1,31);
        _SFD_CV_INIT_EML_RELATIONAL(7,0,0,1,31,-1,4);
        _SFD_CV_INIT_EML(10,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(8,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(9,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(11,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(4,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(24,0,0,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(24,0,0,1,54,1,48);
        _SFD_CV_INIT_EML_RELATIONAL(24,0,0,1,54,-1,2);
        _SFD_CV_INIT_EML(26,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(25,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(27,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(28,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(3,0,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(1,0,0,0,1,0,0,0,0,0,2,1);
        _SFD_CV_INIT_EML_IF(1,0,0,1,43,1,43);

        {
          static int condStart[] = { 1, 30 };

          static int condEnd[] = { 26, 43 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(1,0,0,1,43,2,0,&(condStart[0]),&(condEnd[0]),3,
                                &(pfixExpr[0]));
        }

        _SFD_CV_INIT_EML_RELATIONAL(1,0,0,1,26,-1,0);
        _SFD_CV_INIT_EML_RELATIONAL(1,0,1,30,43,-1,0);
        _SFD_CV_INIT_EML(5,0,0,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(5,0,0,1,14,1,14);
        _SFD_CV_INIT_EML_RELATIONAL(5,0,0,1,14,-1,0);
        _SFD_CV_INIT_EML(12,0,0,0,1,0,0,0,0,0,2,1);
        _SFD_CV_INIT_EML_IF(12,0,0,1,65,1,48);

        {
          static int condStart[] = { 2, 31 };

          static int condEnd[] = { 22, 64 };

          static int pfixExpr[] = { 0, 1, -3 };

          _SFD_CV_INIT_EML_MCDC(12,0,0,2,65,2,0,&(condStart[0]),&(condEnd[0]),3,
                                &(pfixExpr[0]));
        }

        _SFD_CV_INIT_EML_RELATIONAL(12,0,0,2,22,-1,5);
        _SFD_CV_INIT_EML_RELATIONAL(12,0,1,31,64,-1,4);
        _SFD_CV_INIT_EML(2,0,0,0,1,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML_IF(2,0,0,1,14,1,14);
        _SFD_CV_INIT_EML_RELATIONAL(2,0,0,1,14,-1,0);
        _SFD_CV_INIT_EML(1,1,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(6,1,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(8,1,0,0,0,0,0,0,0,0,0,0);
        _SFD_CV_INIT_EML(7,1,0,0,0,0,0,0,0,0,0,0);
        _SFD_SET_DATA_COMPILED_PROPS(0,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(1,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(2,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(3,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(4,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(5,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(6,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(7,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)c2_sf_marshallIn);
        _SFD_SET_DATA_COMPILED_PROPS(15,SF_STRUCT,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)NULL,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(8,SF_UINT8,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_d_sf_marshallOut,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(16,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)NULL,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(17,SF_STRUCT,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_RBC_SEND_MA_bus_io,(MexInFcnForType)NULL);
        _SFD_SET_DATA_COMPILED_PROPS(9,SF_DOUBLE,0,NULL,0,0,0,0.0,1.0,0,0,
          (MexFcnForType)c2_sf_marshallOut,(MexInFcnForType)NULL);

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295U;
          _SFD_SET_DATA_COMPILED_PROPS(10,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295U;
          _SFD_SET_DATA_COMPILED_PROPS(11,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295U;
          _SFD_SET_DATA_COMPILED_PROPS(12,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295U;
          _SFD_SET_DATA_COMPILED_PROPS(13,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        {
          unsigned int dimVector[1];
          dimVector[0]= 4294967295U;
          _SFD_SET_DATA_COMPILED_PROPS(14,SF_DOUBLE,1,&(dimVector[0]),0,0,0,0.0,
            1.0,0,0,(MexFcnForType)NULL,(MexInFcnForType)NULL);
        }

        _SFD_SET_DATA_VALUE_PTR(10,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(11,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(12,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(13,(void *)(NULL));
        _SFD_SET_DATA_VALUE_PTR(14,(void *)(NULL));
      }
    } else {
      sf_debug_reset_current_state_configuration(sfGlobalDebugInstanceStruct,
        _moving_block_decomposed_msg_trainMachineNumber_,
        chartInstance->chartNumber,chartInstance->instanceNumber);
    }
  }
}

static void chart_debug_initialize_data_addresses(SimStruct *S)
{
  if (!sim_mode_is_rtw_gen(S)) {
    SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance =
      (SFc2_moving_block_decomposed_msg_trainInstanceStruct *)
      sf_get_chart_instance_ptr(S);
    if (ssIsFirstInitCond(S)) {
      /* do this only if simulation is starting and after we know the addresses of all data */
      {
        _SFD_SET_DATA_VALUE_PTR(15U, (void *)(c2_PR_msg *)
          chartInstance->c2_RBC_REC_location_msgDataPtr);
        _SFD_SET_DATA_VALUE_PTR(17U, (void *)chartInstance->c2_RBC_SEND_MA);
        _SFD_SET_DATA_VALUE_PTR(8U, (void *)chartInstance->c2_RBC_fail);
        _SFD_SET_DATA_VALUE_PTR(16U, (void *)(real_T *)
          chartInstance->c2_MA_ACK_from_OBU_msgDataPtr);
        _SFD_SET_DATA_VALUE_PTR(5U, (void *)
          &chartInstance->c2_l_timeref_last_MA_sent);
        _SFD_SET_DATA_VALUE_PTR(4U, (void *)&chartInstance->c2_l_count_MA_sent);
        _SFD_SET_DATA_VALUE_PTR(3U, (void *)
          &chartInstance->c2_RBC_REC_location_flg);
        _SFD_SET_DATA_VALUE_PTR(0U, (void *)
          &chartInstance->c2_MA_ACK_from_OBU_flg);
        _SFD_SET_DATA_VALUE_PTR(9U, (void *)
          &chartInstance->c2_INIT_TRAIN_POSITION_VALUE);
        _SFD_SET_DATA_VALUE_PTR(7U, (void *)
          &chartInstance->c2_previous_train_pos);
        _SFD_SET_DATA_VALUE_PTR(6U, (void *)&chartInstance->c2_previous_MA);
        _SFD_SET_DATA_VALUE_PTR(2U, (void *)
          &chartInstance->c2_OBU_current_timestamp);
        _SFD_SET_DATA_VALUE_PTR(1U, (void *)
          &chartInstance->c2_OBU_current_location);
      }
    }
  }
}

static const char* sf_get_instance_specialization(void)
{
  return "sIiAl9QdqxXjM9NdXRRfFWH";
}

static void sf_opaque_initialize_c2_moving_block_decomposed_msg_train(void
  *chartInstanceVar)
{
  chart_debug_initialization
    (((SFc2_moving_block_decomposed_msg_trainInstanceStruct*) chartInstanceVar
     )->S,0);
  initialize_params_c2_moving_block_decomposed_msg_train
    ((SFc2_moving_block_decomposed_msg_trainInstanceStruct*) chartInstanceVar);
  initialize_c2_moving_block_decomposed_msg_train
    ((SFc2_moving_block_decomposed_msg_trainInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_enable_c2_moving_block_decomposed_msg_train(void
  *chartInstanceVar)
{
  enable_c2_moving_block_decomposed_msg_train
    ((SFc2_moving_block_decomposed_msg_trainInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c2_moving_block_decomposed_msg_train(void
  *chartInstanceVar)
{
  disable_c2_moving_block_decomposed_msg_train
    ((SFc2_moving_block_decomposed_msg_trainInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c2_moving_block_decomposed_msg_train(void
  *chartInstanceVar)
{
  sf_gateway_c2_moving_block_decomposed_msg_train
    ((SFc2_moving_block_decomposed_msg_trainInstanceStruct*) chartInstanceVar);
}

static const mxArray*
  sf_opaque_get_sim_state_c2_moving_block_decomposed_msg_train(SimStruct* S)
{
  return get_sim_state_c2_moving_block_decomposed_msg_train
    ((SFc2_moving_block_decomposed_msg_trainInstanceStruct *)
     sf_get_chart_instance_ptr(S));    /* raw sim ctx */
}

static void sf_opaque_set_sim_state_c2_moving_block_decomposed_msg_train
  (SimStruct* S, const mxArray *st)
{
  set_sim_state_c2_moving_block_decomposed_msg_train
    ((SFc2_moving_block_decomposed_msg_trainInstanceStruct*)
     sf_get_chart_instance_ptr(S), st);
}

static void sf_opaque_terminate_c2_moving_block_decomposed_msg_train(void
  *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc2_moving_block_decomposed_msg_trainInstanceStruct*)
                    chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_moving_block_decomposed_msg_train_optimization_info();
    }

    finalize_c2_moving_block_decomposed_msg_train
      ((SFc2_moving_block_decomposed_msg_trainInstanceStruct*) chartInstanceVar);
    utFree(chartInstanceVar);
    if (ssGetUserData(S)!= NULL) {
      sf_free_ChartRunTimeInfo(S);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc2_moving_block_decomposed_msg_train
    ((SFc2_moving_block_decomposed_msg_trainInstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c2_moving_block_decomposed_msg_train(SimStruct *
  S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  if (sf_machine_global_initializer_called()) {
    initialize_params_c2_moving_block_decomposed_msg_train
      ((SFc2_moving_block_decomposed_msg_trainInstanceStruct*)
       sf_get_chart_instance_ptr(S));
  }
}

static void mdlSetWorkWidths_c2_moving_block_decomposed_msg_train(SimStruct *S)
{
  ssSetInputPortDirectFeedThrough(S, 0, 1);
  ssSetInputPortDirectFeedThrough(S, 1, 1);
  ssSetInputPortDirectFeedThrough(S, 2, 1);
  ssSetStatesModifiedOnlyInUpdate(S, 0);
  ssSetBlockIsPurelyCombinatorial_wrapper(S, 0);
  ssMdlUpdateIsEmpty(S, 1);
  ssSetNeedAbsoluteTime(S,1);
  if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
    mxArray *infoStruct =
      load_moving_block_decomposed_msg_train_optimization_info
      (sim_mode_is_rtw_gen(S), sim_mode_is_modelref_sim(S), sim_mode_is_external
       (S));
    int_T chartIsInlinable =
      (int_T)sf_is_chart_inlinable(sf_get_instance_specialization(),infoStruct,2);
    ssSetStateflowIsInlinable(S,chartIsInlinable);
    ssSetRTWCG(S,1);
    ssSetEnableFcnIsTrivial(S,1);
    ssSetDisableFcnIsTrivial(S,1);
    ssSetNotMultipleInlinable(S,sf_rtw_info_uint_prop
      (sf_get_instance_specialization(),infoStruct,2,
       "gatewayCannotBeInlinedMultipleTimes"));
    sf_set_chart_accesses_machine_info(S, sf_get_instance_specialization(),
      infoStruct, 2);
    sf_update_buildInfo(S, sf_get_instance_specialization(),infoStruct,2);
    if (chartIsInlinable) {
      ssSetInputPortOptimOpts(S, 0, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 1, SS_REUSABLE_AND_LOCAL);
      ssSetInputPortOptimOpts(S, 2, SS_REUSABLE_AND_LOCAL);
      sf_mark_chart_expressionable_inputs(S,sf_get_instance_specialization(),
        infoStruct,2,3);
      sf_mark_chart_reusable_outputs(S,sf_get_instance_specialization(),
        infoStruct,2,1);
    }

    {
      unsigned int outPortIdx;
      for (outPortIdx=1; outPortIdx<=1; ++outPortIdx) {
        ssSetOutputPortOptimizeInIR(S, outPortIdx, 1U);
      }
    }

    {
      unsigned int inPortIdx;
      for (inPortIdx=0; inPortIdx < 3; ++inPortIdx) {
        ssSetInputPortOptimizeInIR(S, inPortIdx, 1U);
      }
    }

    sf_set_rtw_dwork_info(S,sf_get_instance_specialization(),infoStruct,2);
    sf_register_codegen_names_for_scoped_functions_defined_by_chart(S);
    ssSetHasSubFunctions(S,!(chartIsInlinable));
  } else {
  }

  ssSetOptions(S,ssGetOptions(S)|SS_OPTION_WORKS_WITH_CODE_REUSE);
  ssSetChecksum0(S,(156648473U));
  ssSetChecksum1(S,(2170923893U));
  ssSetChecksum2(S,(2620980574U));
  ssSetChecksum3(S,(3542874582U));
  ssSetmdlDerivatives(S, NULL);
  ssSetExplicitFCSSCtrl(S,1);
  ssSetStateSemanticsClassicAndSynchronous(S, true);
  ssSupportsMultipleExecInstances(S,1);
}

static void mdlRTW_c2_moving_block_decomposed_msg_train(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Stateflow");
  }
}

static void mdlStart_c2_moving_block_decomposed_msg_train(SimStruct *S)
{
  SFc2_moving_block_decomposed_msg_trainInstanceStruct *chartInstance;
  chartInstance = (SFc2_moving_block_decomposed_msg_trainInstanceStruct *)
    utMalloc(sizeof(SFc2_moving_block_decomposed_msg_trainInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  memset(chartInstance, 0, sizeof
         (SFc2_moving_block_decomposed_msg_trainInstanceStruct));
  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 0;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway =
    sf_opaque_gateway_c2_moving_block_decomposed_msg_train;
  chartInstance->chartInfo.initializeChart =
    sf_opaque_initialize_c2_moving_block_decomposed_msg_train;
  chartInstance->chartInfo.terminateChart =
    sf_opaque_terminate_c2_moving_block_decomposed_msg_train;
  chartInstance->chartInfo.enableChart =
    sf_opaque_enable_c2_moving_block_decomposed_msg_train;
  chartInstance->chartInfo.disableChart =
    sf_opaque_disable_c2_moving_block_decomposed_msg_train;
  chartInstance->chartInfo.getSimState =
    sf_opaque_get_sim_state_c2_moving_block_decomposed_msg_train;
  chartInstance->chartInfo.setSimState =
    sf_opaque_set_sim_state_c2_moving_block_decomposed_msg_train;
  chartInstance->chartInfo.getSimStateInfo =
    sf_get_sim_state_info_c2_moving_block_decomposed_msg_train;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c2_moving_block_decomposed_msg_train;
  chartInstance->chartInfo.mdlStart =
    mdlStart_c2_moving_block_decomposed_msg_train;
  chartInstance->chartInfo.mdlSetWorkWidths =
    mdlSetWorkWidths_c2_moving_block_decomposed_msg_train;
  chartInstance->chartInfo.callGetHoverDataForMsg =
    sf_opaque_get_hover_data_for_msg;
  chartInstance->chartInfo.extModeExec = NULL;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.callAtomicSubchartUserFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartAutoFcn = NULL;
  chartInstance->chartInfo.debugInstance = sfGlobalDebugInstanceStruct;
  chartInstance->S = S;
  sf_init_ChartRunTimeInfo(S, &(chartInstance->chartInfo), false, 0);
  init_dsm_address_info(chartInstance);
  init_simulink_io_address(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  chart_debug_initialization(S,1);
  mdl_start_c2_moving_block_decomposed_msg_train(chartInstance);
}

void c2_moving_block_decomposed_msg_train_method_dispatcher(SimStruct *S, int_T
  method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c2_moving_block_decomposed_msg_train(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c2_moving_block_decomposed_msg_train(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c2_moving_block_decomposed_msg_train(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c2_moving_block_decomposed_msg_train_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
